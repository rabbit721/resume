/*
 * Name: Jie Jiao
 * Andrew ID: jiejiao
 */

/*
 * tsh - simulator for an interactive program that runs other programs
 *       on behalf of the user
 *
 *       It performs a sequence of read/evaluate steps and then terminates. The
 *       read step reads a command line from the user. The evaluate step parses
 *       the command line and runs the programs on behalf of the user.
 *
 *       More specifically, it repeatedly prints a prompt, waits for a command
 *       line on stdin, and then carries out some action, as directed by the
 *       contents of the command line.
 *
 *       A job list is used to keep track of stopped or running processes to
 *       support queries. We add a process to the job list in the parent process
 *       after creating a child process for the command using fork,
 *       and delete a terminated process from the job list in sigchld_handler
 *       when the command in child process finished executing.
 *
 * main functions explained:
 *       eval: Main routine that parses, interprets, and executes the command
 *             line
 *       sigchld handler: Handles SIGCHLD signals
 *       sigint handler: Handles SIGINT signals (sent by Ctrl-C).
 *       sigtstp handler: Handles SIGTSTP signals (sent by Ctrl-Z).
 *
 */

#include "csapp.h"
#include "tsh_helper.h"

#include <sys/wait.h>
#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/*
 * If DEBUG is defined, enable contracts and printing on dbg_printf.
 */
#ifdef DEBUG
/* When debugging is enabled, these form aliases to useful functions */
#define dbg_printf(...) printf(__VA_ARGS__)
#define dbg_requires(...) assert(__VA_ARGS__)
#define dbg_assert(...) assert(__VA_ARGS__)
#define dbg_ensures(...) assert(__VA_ARGS__)
#else
/* When debugging is disabled, no code gets generated for these */
#define dbg_printf(...)
#define dbg_requires(...)
#define dbg_assert(...)
#define dbg_ensures(...)
#endif

/* Function prototypes */
void eval(const char *cmdline);

void sigchld_handler(int sig);
void sigtstp_handler(int sig);
void sigint_handler(int sig);
void sigquit_handler(int sig);
void cleanup(void);

pid_t Fork();
int Sigprocmask(int how, const sigset_t *set, sigset_t *oldset);
int handle_builtin(struct cmdline_tokens token, const char *cmdline);
void handle_error(int errN, char *file);
int Open(char *outfile, char *infile);
void Close();

volatile pid_t fg_pid; // used to keep track of a terminated fg process
volatile int outfd; // outfile descriptor
volatile int infd; // outfile descriptor
volatile int stdoutfd; // stdout copy, used to restore stdout after closing
                       // outfd
volatile int stdinfd; // stdin copy, used to restore stdin after closing infd
/*
 * Usage: Initializes environment and job list, parses command line, iteratively
 *        call eval to process the command. Redirect I/O for errors and print
 *        statements to print in stdout.
 *
 * Arguments: argc - contains the number of arguments passed to the program.
 *            argv - "argument vector", a one-dimensional array of strings.
 *
 * Return: If encountered error when setting up environment and I/O or parsing,
 *         exit with status code 1, else return 0 normally
 */
int main(int argc, char **argv) {
  char c;
  char cmdline[MAXLINE_TSH]; // Cmdline for fgets
  bool emit_prompt = true;   // Emit prompt (default)

  // Redirect stderr to stdout (so that driver will get all output
  // on the pipe connected to stdout)
  if (dup2(STDOUT_FILENO, STDERR_FILENO) < 0) {
    perror("dup2 error");
    exit(1);
  }

  // Parse the command line
  while ((c = getopt(argc, argv, "hvp")) != EOF) {
    switch (c) {
    case 'h': // Prints help message
      usage();
      break;
    case 'v': // Emits additional diagnostic info
      verbose = true;
      break;
    case 'p': // Disables prompt printing
      emit_prompt = false;
      break;
    default:
      usage();
    }
  }

  // Create environment variable
  if (putenv("MY_ENV=42") < 0) {
    perror("putenv");
    exit(1);
  }

  // Set buffering mode of stdout to line buffering.
  // This prevents lines from being printed in the wrong order.
  if (setvbuf(stdout, NULL, _IOLBF, 0) < 0) {
    perror("setvbuf");
    exit(1);
  }

  // Initialize the job list
  init_job_list();

  // Register a function to clean up the job list on program termination.
  // The function may not run in the case of abnormal termination (e.g. when
  // using exit or terminating due to a signal handler), so in those cases,
  // we trust that the OS will clean up any remaining resources.
  if (atexit(cleanup) < 0) {
    perror("atexit");
    exit(1);
  }

  // Install the signal handlers
  Signal(SIGINT, sigint_handler);   // Handles Ctrl-C
  Signal(SIGTSTP, sigtstp_handler); // Handles Ctrl-Z
  Signal(SIGCHLD, sigchld_handler); // Handles terminated or stopped child

  Signal(SIGTTIN, SIG_IGN);
  Signal(SIGTTOU, SIG_IGN);

  Signal(SIGQUIT, sigquit_handler);

  // Execute the shell's read/eval loop
  while (true) {
    if (emit_prompt) {
      printf("%s", prompt);

      // We must flush stdout since we are not printing a full line.
      fflush(stdout);
    }

    if ((fgets(cmdline, MAXLINE_TSH, stdin) == NULL) && ferror(stdin)) {
      perror("fgets error");
      exit(1);
    }

    if (feof(stdin)) {
      // End of file (Ctrl-D)
      printf("\n");
      return 0;
    }

    // Remove any trailing newline
    char *newline = strchr(cmdline, '\n');
    if (newline != NULL) {
      *newline = '\0';
    }

    // Evaluate the command line
    eval(cmdline);
  }

  return -1; // control never reaches here
}

/*
 * Usage: evaluates the command parsed by main.
 *        Handles built-in command and executable objects separately.
 *        If command is builtin (jobs, bg, fg, quit), call handle_builtin
 *        Else use fork to create a child process in which the process is run,
 *             block SIGCHLD, SIGINT, SIGTSTP because if it's a foreground
 *             process we want parent to wait for the process to finish.
 *             If it's a background process, we don't wait for it.
 *             But for both fg and bg processes, add them to job list.
 *
 * Arguments: cmdline - original input commands in the terminal
 * Return: Nothing
 *
 * NOTE: The shell is supposed to be a long-running process, so this function
 *       (and its helpers) should avoid exiting on error.  This is not to say
 *       they shouldn't detect and print (or otherwise handle) errors!
 */
void eval(const char *cmdline) {
  parseline_return parse_result;
  struct cmdline_tokens token;
  pid_t pid;
  jid_t jid;
  outfd = 0;
  stdoutfd = 0;
  sigset_t mask_all, mask_one, prev_one;
  // Parse command line
  parse_result = parseline(cmdline, &token);

  if (parse_result == PARSELINE_ERROR || parse_result == PARSELINE_EMPTY) {
    return;
  }

  sigfillset(&mask_all);
  sigemptyset(&mask_one);
  sigaddset(&mask_one, SIGCHLD);
  sigaddset(&mask_one, SIGINT);
  sigaddset(&mask_one, SIGTSTP);
  // try to make it respond to quit

  // if command is a builtin statement, handle it and return
  if (handle_builtin(token, cmdline)) {
    return;
  }

  // if command is an executable object
  /* Block SIGCHLD, SIGINT, SIGTSTP */
  Sigprocmask(SIG_BLOCK, &mask_one, &prev_one);

  if ((pid = Fork()) == 0) { /* Child process */
    /* unblock SIGCHLD in child process */
    Sigprocmask(SIG_SETMASK, &prev_one, NULL);
    setpgid(0, 0);
    // If error occurred in open, exit
    if (Open(token.outfile, token.infile) < 0) {
      Close();
      exit(1);
    }

    if (execve(token.argv[0], token.argv, environ) < 0) {
      sio_printf("failed to execute: %s\n", token.argv[0]);
      Close();
      exit(1);
    }
  } else {
    /* Add the child to the job list */
    if (!parse_result) { // parent of foreground job
      Sigprocmask(SIG_BLOCK, &mask_all, NULL); // block every signal
      jid = add_job(pid, FG, cmdline);
      //wait for the foreground process to finish
      fg_pid = 0;
      while (!fg_pid) {
        sigsuspend(&prev_one);
      }

      Sigprocmask(SIG_SETMASK, &prev_one, NULL);
    } else { // parent of background job: print pid
      Sigprocmask(SIG_BLOCK, &mask_all, NULL); // block every signal
      jid = add_job(pid, BG, cmdline);
      sio_printf("[%d] (%d) %s\n", jid, pid, cmdline);
      Sigprocmask(SIG_SETMASK, &prev_one, NULL);
    }
    Close();
  }
}

/*****************
 * Signal handlers
 *****************/

/*
 * Usage: The function is triggered upon the program receiving a sigchld. It
 *        should not be called directly. It handles all children processes that
 *        are stopped and terminated when this function is called.
 *        It checks if the signal comes from a foreground process and sets
 *        fg_pid accordingly.
 *        If also checks if the child process that sent the SIGCHLD signal
 *        is terminated, if so, it should delete it from the joblist.
 *                       else, it should not modify joblist.
 *
 *        It should be async-signal-safe, so save and restore errno.
 *
 * Arguments: sig - signal number of SIGCHLD
 * Return: Nothing
 */
void sigchld_handler(int sig) {
  int olderrno = errno;

  sigset_t mask_all, prev_all;
  pid_t pid;
  jid_t jid;
  int status;
  sigfillset(&mask_all);
  while ((pid = waitpid(-1, &status, WNOHANG | WUNTRACED)) >
         0) { /* Reap child */
    Sigprocmask(SIG_BLOCK, &mask_all, &prev_all);
    jid = job_from_pid(pid);
    if (job_get_state(jid) == FG) {
      fg_pid = pid;
    }
    if (WIFSTOPPED(status)) {
      job_set_state(jid, ST);
      sio_printf("Job [%d] (%d) stopped by signal %d\n", jid, pid,
                 WSTOPSIG(status));
    } else {
      delete_job(jid); /* Delete the child from the job list */
      if (WIFSIGNALED(status)) {
        sio_printf("Job [%d] (%d) terminated by signal %d\n", jid, pid,
                   WTERMSIG(status));
      }
    }

    Sigprocmask(SIG_SETMASK, &prev_all, NULL);
  }
  errno = olderrno;
}

/* Usage: The function is triggered by interrupt from the keyboard (Ctrl-C).
 *        It should not be called directly. It terminates current foreground job
 *        if have one.
 *
 *        It should be async-signal-safe, so save and restore errno.
 *
 * Arguments: sig - signal number of SIGINT
 * Return: Nothing
 */
void sigint_handler(int sig) {
  jid_t jid;
  pid_t pid;
  sigset_t mask_all, prev_all;
  int olderrno = errno;
  sigfillset(&mask_all);

  Sigprocmask(SIG_BLOCK, &mask_all, &prev_all); /* Block everything */
  jid = fg_job();
  if (jid) { // if there is a foreground process runnning, terminate it
    pid = job_get_pid(jid);
    if (pid) {
      kill(-pid, sig);
    }
  }
  Sigprocmask(SIG_SETMASK, &prev_all, NULL);
  errno = olderrno;
}

/*
 * Usage: The function is triggered by interrupt from the keyboard (Ctrl-Z).
 *        It should not be called directly. It stops current foreground job
 *        if have one.
 *
 *        It should be async-signal-safe, so save and restore errno.
 *
 * Arguments: sig - signal number of SIGTSTP
 * Return: Nothing
 */
void sigtstp_handler(int sig) {
  jid_t jid;
  pid_t pid;
  sigset_t mask_all, prev_all;
  int olderrno = errno;
  sigfillset(&mask_all);

  Sigprocmask(SIG_BLOCK, &mask_all, &prev_all); /* Block everything */
  jid = fg_job();
  if (jid) { // if there is a foreground process runnning, stop it
    pid = job_get_pid(jid);
    if (pid) {
      kill(-pid, sig);
    }
  }
  Sigprocmask(SIG_SETMASK, &prev_all, NULL);
  errno = olderrno;
}

/*
 * Usage: Attempts to clean up global resources when the program exits. In
 *        particular, the job list must be freed at this time, since it may
 *        contain leftover buffers from existing or even deleted jobs.
 *
 * Arguments: Nothing
 * Return: Nothing
 */
void cleanup(void) {
  // Signals handlers need to be removed before destroying the joblist
  Signal(SIGINT, SIG_DFL);  // Handles Ctrl-C
  Signal(SIGTSTP, SIG_DFL); // Handles Ctrl-Z
  Signal(SIGCHLD, SIG_DFL); // Handles terminated or stopped child

  destroy_job_list();
}

/*
 * Usage: Wrapper function for fork, also deals with error handling
 *
 * Arguments: Nothing
 * Return: the return value of fork
 *
 */
pid_t Fork(void) {
  pid_t pid;
  if ((pid = fork()) < 0) {
    sio_eprintf("Fork error\n");
  }
  return pid;
}

/*
 * Usage: Wrapper function for sigprocmask, used to fetch and/or change the
 *        signal mask of the calling thread.  The signal mask is the set of
 *        signals whose delivery is currently blocked for the caller.
 *        Also handles any error of sigprocmask.
 *
 *        It should be async-signal-safe, so save and restore errno.
 *
 * Arguments: same arguments as sigprocmask
 * Return: the return value of sigprocmask
 *
 */
int Sigprocmask(int how, const sigset_t *set, sigset_t *oldset) {
  int olderrno = errno;
  int ret;
  if ((ret = sigprocmask(how, set, oldset)) < 0) {
    sio_printf("sigprocmask errno: %d", errno);
  }
  errno = olderrno;
  return ret;
}

/*
 * Usage: handles the bg/fg builtin command
 *
 * Arguments: background - set to 1 if bg command, 0 if fg command
 *            arg - argument string following the bg/fg command,
 *                should be in the form %jid or pid if valid
 *            cmdline - original input commands in the terminal
 *
 * Return: Nothing
 */
void handle_switchstate(int background, char *arg, const char *cmdline) {
  jid_t jid;
  pid_t pid;
  sigset_t mask_all, prev_all;
  sigfillset(&mask_all);

  Sigprocmask(SIG_BLOCK, &mask_all, &prev_all); /* Block everything */
  if (arg == NULL) {
    if (!background) { // error message for foreground
      sio_printf("fg command requires PID or %%jobid argument\n");
    } else {
      sio_printf("bg command requires PID or %%jobid argument\n");
    }
    Sigprocmask(SIG_SETMASK, &prev_all, NULL);
    return;
  }
  if (arg[0] == '%') { // the following is a job id
    jid = atoi(&arg[1]);
    if (!job_exists(jid)) {
      sio_printf("%%%d: No such job\n", jid);
      Sigprocmask(SIG_SETMASK, &prev_all, NULL);
      return;
    }
    pid = job_get_pid(jid);

  } else if (isdigit(arg[0])) { // arg[0] is a number
    pid = atoi(arg);
    jid = job_from_pid(pid);
    if (jid <= 0) {
      sio_printf("%%%d: No such job\n", pid);
      Sigprocmask(SIG_SETMASK, &prev_all, NULL);
      return;
    }
  } else {
    if (!background) {
      sio_printf("fg: argument must be a PID or %%jobid\n");
    } else {
      sio_printf("bg: argument must be a PID or %%jobid\n");
    }
    Sigprocmask(SIG_SETMASK, &prev_all, NULL);
    return;
  }

  kill(-pid, SIGCONT);

  if (background) {
    job_set_state(jid, BG);
    sio_printf("[%d] (%d) %s\n", jid, pid, job_get_cmdline(jid));
  } else {
    job_set_state(jid, FG);
    fg_pid = 0; // there cannot be a foreground running
    while (!fg_pid) {
      sigsuspend(&prev_all);
    }
  }
  Sigprocmask(SIG_SETMASK, &prev_all, NULL);
}

/*
 * Usage: handles builtin command:
 *        quit: quit the shell directly
 *        bg/fg id: send sig continues to the process with the jid/pid,
 *                  handled in handle_switchstates
 *        jobs: list the jobs currently in job list
 *
 * Arguments: token - a struct cmdline_tokens returned by parseline
 *            cmdline - original input commands in the terminal
 * Return: 1 if handled a builtin command, 0 if command is not builtin
 *
 */
int handle_builtin(struct cmdline_tokens token, const char *cmdline) {
  sigset_t mask_all, prev_one;
  sigfillset(&mask_all);

  switch (token.builtin) {
  case BUILTIN_QUIT:
    exit(0);
    break;

  case BUILTIN_JOBS:
    if (Open(token.outfile, token.infile) < 0)
      return 1;
    Sigprocmask(SIG_BLOCK, &mask_all, &prev_one); // block every signal
    list_jobs(1);
    Sigprocmask(SIG_SETMASK, &prev_one, NULL);
    Close();
    return 1;

  case BUILTIN_BG:
    if (Open(token.outfile, token.infile) < 0)
      return 1;
    handle_switchstate(1, token.argv[1], cmdline);
    Close();
    return 1;

  case BUILTIN_FG:
    if (Open(token.outfile, token.infile) < 0)
      return 1;
    handle_switchstate(0, token.argv[1], cmdline);
    Close();
    return 1;

  default:
    return 0;
  }
}

/*
 * Usage: A wrapper function for open, opens an infile/outfile with error
 *        handling using handle_error
 *
 * Arguments: outfile - the filename of the outfile, NULL if not provided
 *            infile - the filename of the infile, NULL if not provided
 * Return: the return value of open
 *
 * NOTE: Since we always open with flag O_CLOEXEC, we don't need to explicitly
 *       close any out/infile.
 */
int Open(char *outfile, char *infile) {
  if (outfile) {
    outfd = open(outfile, O_WRONLY | O_CLOEXEC | O_CREAT | O_TRUNC, 0644);
    if (outfd < 0) {
      handle_error(errno, outfile);
      Close();
      return -1;
    }
    stdoutfd = dup(1);
    if (dup2(outfd, 1) < 0) {
      sio_printf("dup2 for outfile failed");
      Close();
      return -1;
    }
  }

  if (infile) {
    infd = open(infile, O_RDONLY | O_CLOEXEC, 0644);
    if (infd < 0) {
      handle_error(errno, infile);
      Close();
      return -1;
    }
    stdinfd = dup(0);
    if (dup2(infd, 0) < 0) {
      sio_printf("dup2 for infile failed");
      Close();
      return -1;
    }
  }
  return 0;
}

/*
 * Usage: Closes any open infile or outfile, also restore stdin and stdout to
 *        their original state
 *
 * Arguments: Nothing
 * Return: Nothing
 *
 */
void Close() {
  if (outfd) {
    if (stdoutfd)
      dup2(stdoutfd, 1);
    stdoutfd = 0;
    outfd = 0;
  }

  if (infd) {
    if (stdinfd)
      dup2(stdinfd, 0);
    stdinfd = 0;
    infd = 0;
  }
}

/*
 * Usage: Gives ppropriate print statements when an error occurs when opening
 *        a file.
 *
 * Arguments: errN - the errno when an error is detected when opening a file
 *            file - the filename of the file being opened
 * Return: Nothing
 *
 */
void handle_error(int errN, char *file) {
  if (errN == ENOENT) {
    sio_printf("%s: No such file or directory\n", file);
  } else if (errN == EACCES) {
    sio_printf("%s: Permission denied\n", file);
  } else {
    sio_printf("errno: %d\n", errN);
  }
}
