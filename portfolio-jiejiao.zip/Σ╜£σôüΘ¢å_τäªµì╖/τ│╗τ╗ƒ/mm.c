/*
 ******************************************************************************
 *                                   mm.c                                     *
 *           64-bit struct-based implicit free list memory allocator          *
 *                  15-213: Introduction to Computer Systems                  *
 *                                                                            *
 *  ************************************************************************  *
 *  Andrew ID: jiejiao                                                        *
 *  Name: Jie Jiao                                                            *
 *  Segregated Free List Implementation Explanation:                          *
 *  - Keep track of an array of linked lists of free blocks of differennt     *
 *    size classes, seglist                                                   *
 *  - Initialize seg list when initializing the heap, let the explist point to*
 *    the first free block we allocated.                                      *
 *  - Updating seg list:                                                      *
 *    - When freeing a block, insert or update based on the four cases of     *
 *      coalesing                                                             *
 *    - When allocating a block, update or delete based on the result of      *
 *      splitting                                                             *
 *                                                                            *
 *  - Find_fit strategy: first_fit                                            *

      difference between checkpoint and final
      Struct redesigned:
      - None-mini blocks:
       - Header:
         63                           3        2           1         0
         |             size           0 | prev_mini | prev_alloc | alloc
       - If allocated: have payload
         else: - have prev and next pointer pointing to previous and next free
                 blocks in the explist of current size class
               - Also have footer for coalesing

      - For mini block (size 16):
       - prev_in_list:
         63                           3        2           1         0
         |         prev_mini_ptr      1 | prev_mini | prev_alloc | alloc
       - next: pointer to next block in the list
       - Only update prev_mini_ptr when inserting/removing block in mini list
       - Checking if a block is mini by checking the first 8 bytes in the block
         If the fourth LSB is 0, then not mini block (because size is always
                                 a multiple of 16)
         If 1 then mini block, because pointer addresses are only 8-byte aligned
       - Don't need to keep track of size since mini has size 16

      Other free blocks (not mini block):
       - same header structure like allockated blocks
       - still have header, prev, next; same as before

      LIFO: insert_block add to the front of an explist,
            find_fit_explist return the first block in the explist with enought
            size

      fit policy: find the smallest of 6 fit blocks
 *                                                                            *
 ******************************************************************************
 */

#include <assert.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "memlib.h"
#include "mm.h"

/* Do not change the following! */

#ifdef DRIVER
/* create aliases for driver tests */
#define malloc mm_malloc
#define free mm_free
#define realloc mm_realloc
#define calloc mm_calloc
#define memset mem_memset
#define memcpy mem_memcpy
#endif /* def DRIVER */

/* You can change anything from here onward */

/*
 * If DEBUG is defined (such as when running mdriver-dbg), these macros
 * are enabled. You can use them to print debugging output and to check
 * contracts only in debug mode.
 *
 * Only debugging macros with names beginning "dbg_" are allowed.
 * You may not define any other macros having arguments.
 */
#ifdef DEBUG
/* When DEBUG is defined, these form aliases to useful functions */
#define dbg_printf(...) printf(__VA_ARGS__)
#define dbg_requires(expr) assert(expr)
#define dbg_assert(expr) assert(expr)
#define dbg_ensures(expr) assert(expr)
#define dbg_printheap(...) print_heap(__VA_ARGS__)
#else
/* When DEBUG is not defined, no code gets generated for these */
/* The sizeof() hack is used to avoid "unused variable" warnings */
#define dbg_printf(...) (sizeof(__VA_ARGS__), -1)
#define dbg_requires(expr) (sizeof(expr), 1)
#define dbg_assert(expr) (sizeof(expr), 1)
#define dbg_ensures(expr) (sizeof(expr), 1)
#define dbg_printheap(...) ((void)sizeof(__VA_ARGS__))
#endif
// ALIGN used to check 16 alignment of payload
#define ALIGN 16L
#define OFFSET 7
#define DUMMYPTR 8

/* Basic constants */

// a word is 8 bytes
typedef uint64_t word_t;

// Word and header size (bytes)
static const size_t wsize = sizeof(word_t);

// Double word size (bytes)
static const size_t dsize = 2 * wsize;

// Minimum block size (bytes)
static const size_t min_block_size = dsize;

// chunksize is the size of memory we extend heap with when no space left
// (Must be divisible by dsize)
static const size_t chunksize = (1 << 12);

/* alloc_mask is applied to header and footer to find out if the
 * the block is allocated or freed */
static const word_t alloc_mask = 0x1;

/* prev_alloc_mask is applied to header and footer to find out if the
 * the previous block in the current explist is allocated or freed */
static const word_t prev_alloc_mask = 0x2;

/* prev_mini_mask is applied to header and footer to find out if the
 * the previous block in the heap is mini block or not*/
static const word_t prev_mini_mask = 0x4;

/* prev_mini_mask is applied to header to find out if the current block is mini
 */
static const word_t mini_mask = 0x8;

/* pointer mask is applied to header of a mini block to get the pointer to prev
 * mini block in list from the field prev_in_list */
static const word_t pointer_mask = ~(word_t)0x7;

// size_mask is applied to mask out the lower 4 bits to get size of payload
static const word_t size_mask = ~(word_t)0xF;

/* Represents the header and payload of one block in the heap
 * The union deals with the difference in allocated and free blocks */

/* For none-mini blocks */
typedef struct block {
  /* Header structure: size + lower three bits: prev_mini, prev_alloc, alloc */
  word_t header;
  union {
    char payload[0]; // for content of allocated blocks
    struct {
      /* for free blocks that are not mini :
          - next is next free block in the current explist;
          - prev is previous free block in the current explist;
      */
      struct block *next;
      struct block *prev;
    } dir;
  } content;
} block_t;

/* declaration of mini block: */
typedef struct mini_block {
  /* Header: | prev_in_list | prev_mini | prev_alloc | alloc
   * prev_in_list: pointer to previous free block in the mini block explist
   * Exploiting the fact that pointers are 8-byte aligned, lower three bits are
   * always 0, so use them to store three bits: prev_mini, prev_alloc, alloc
   * - prev_mini: if the previous block in the heap is mini_block
   * - prev_alloc: if the previous block is allocated
   * - alloc: if current block is alloc
   *
   * next: pointer to next free block in the linked list */
  word_t prev_in_list;
  struct mini_block *next;
} mini_block_t;

/* Global variables */

/* Implementation of Segregated free lists:
 * Use an array of array of block_t, each list have blocks of below sizes
 */
// static const int search_range = 5;
static const size_t class_sizes = 15;
static const size_t block_sizes[class_sizes - 1] = {
  16, 32, 48, 64, 96, 128, 160, 256, 512, 1024, 2048, 4096, 8192, 16384
};

/* Segregated free list: an array of explicit free list each containing blocks
 * of different sizes */
static block_t *seglist[class_sizes];

// Pointer to first block
static block_t *heap_start;

/* Function prototypes for internal helper routines */

bool mm_checkheap(int lineno);

static block_t *extend_heap(size_t size);
static block_t *find_fit(size_t asize);
static block_t *coalesce_block(block_t *block);
static void split_block(block_t *block, size_t asize);

static size_t max(size_t x, size_t y);
static size_t round_up(size_t size, size_t n);
static word_t pack(size_t size, bool prev_mini, bool prev_alloc, bool alloc);
static bool isMini(block_t *block);

static size_t extract_size(word_t header);
static size_t get_size(block_t *block);
static size_t get_payload_size(block_t *block);

static size_t extract_prev_mini_ptr(word_t header);
static size_t get_prev_mini_ptr(mini_block_t *block);

static bool extract_prev_alloc(word_t header);
static bool get_prev_alloc(block_t *block);

static bool extract_prev_mini(word_t header);
static bool get_prev_mini(block_t *block);

static bool extract_alloc(word_t header);
static bool get_alloc(block_t *block);

static void write_header(block_t *block, size_t size, bool prev_mini,
                         bool prev_alloc, bool alloc);
static void write_footer(block_t *block, size_t size, bool prev_mini,
                         bool prev_alloc, bool alloc);

static block_t *payload_to_header(void *bp);
static void *header_to_payload(block_t *block);
static word_t *header_to_footer(block_t *block);

static block_t *find_next(block_t *block);
static word_t *find_prev_footer(block_t *block);
static block_t *find_prev(block_t *block);
static block_t *prev_mini_heap(block_t *block);
static void update_prev_in_list(mini_block_t *mini, void *prev_block);

static void rewrite_block(block_t *block, bool new, size_t size, bool prev_mini,
                          bool prev_alloc, bool alloc);
static void rewrite_curr(block_t *block, size_t new_size, bool new_alloc);
static void rewrite_prev(block_t *block, bool new_prev_mini,
                         bool new_prev_alloc);

static block_t *get_next(block_t *block);
static block_t *get_prev(block_t *block);
static void replace(block_t *old, block_t *new);
static size_t get_class(size_t size);
static void insert_block(block_t *block, size_t class_index);
static void remove_mini_block(block_t *block);
static void remove_block(block_t *block, size_t class_index);
static void print_heap();
static void print_list();

/* Initialize the heap
 * Arguments: None
 * Ensures: returns a bool indicating if initialization is successful
 */
bool mm_init(void) {
  // Create the initial empty heap
  word_t *start = (word_t *)(mem_sbrk(2 * wsize));

  if (start == (void *)-1) {
    return false;
  }
  // pack(size_t size, bool prev_mini, bool prev_alloc, bool alloc);
  start[0] = pack(0, false, true, true); // Heap prologue (block footer)
  start[1] = pack(0, false, true, true); // Heap epilogue (block header)

  for (size_t i = 0; i < class_sizes; i++) {
    seglist[i] = NULL;
  }
  // Heap starts with first "block header", currently the epilogue
  heap_start = (block_t *)&(start[1]);

  // Extend the empty heap with a free block of chunksize bytes
  if (extend_heap(chunksize) == NULL) {
    return false;
  }
  dbg_requires(mm_checkheap(__LINE__));
  return true;
}

/*
 * malloc: returns a pointer to an allocated block payload of at least size
 *         bytes
 * Arguments: size is the size of the memory requested to be allocated
 * Ensures: always return 16-byte aligned pointers
 */
void *malloc(size_t size) {
  dbg_requires(mm_checkheap(__LINE__));
  dbg_printf("ENTERing malloc with request size %zu\n", size);
  print_heap();
  print_list();
  size_t asize;      // Adjusted block size
  size_t extendsize; // Amount to extend heap if no fit is found
  block_t *block;
  void *bp = NULL;

  if (heap_start == NULL) // Initialize heap if it isn't initialized
  {
    mm_init();
  }

  if (size == 0) // Ignore spurious request
  {
    dbg_ensures(mm_checkheap(__LINE__));
    return bp;
  }

  // Adjust block size to include header and to meet alignment requirements
  asize = round_up(size + wsize, dsize);

  // Search the free list for a fit
  block = find_fit(asize);

  // If no fit is found, request more memory, and then place the block
  if (block == NULL) {
    // Always request at least chunksize
    extendsize = max(asize, chunksize);
    block = extend_heap(extendsize);
    if (block == NULL) // extend_heap returns an error
    {
      return bp;
    }
  }

  // The block should be marked as free
  dbg_assert(!get_alloc(block));

  // Mark block as allocated
  size_t block_size = get_size(block);
  remove_block(block, get_class(block_size));

  rewrite_curr(block, get_size(block), true);

  // also need to udpate the header of next block in the heap
  // next block cannot be free
  block_t *block_next = find_next(block);

  rewrite_prev(block_next, false, true);

  // Try to split the block if too large, also handles removing from seglist
  split_block(block, asize);

  bp = header_to_payload(block);

  dbg_ensures(mm_checkheap(__LINE__));
  dbg_printf("EXITing malloc \n");
  // print_heap();
  return bp;
}

/* free: frees block pointed to by bp.
 * arguments: a pointer, pointing to the memory need to be freed
 * ensures: the pointer is NULL after freeing.
 */
void free(void *bp) {
  dbg_requires(mm_checkheap(__LINE__));

  // print_heap();
  if (bp == NULL) {
    return;
  }

  block_t *block = payload_to_header(bp);
  dbg_printf("ENTERing free with block %p\n", block);

  // The block should be marked as allocated
  dbg_assert(get_alloc(block));
  // Mark the block as free
  rewrite_curr(block, get_size(block), false);

  // Need to rewrite next block in the heap to udpate prev_alloc, prev_mini
  block_t *next_block = find_next(block);
  rewrite_prev(next_block, isMini(block), false);

  // Try to coalesce the block with its neighbors
  block = coalesce_block(block);
  dbg_ensures(mm_checkheap(__LINE__));
  dbg_printf("EXITing free \n");
}

/*
 * realloc: realloces the block pointed to by ptr
 * arguments: ptr: a pointer whose block need to be reallocated
 *            size: the new size
 * requires: the block pointed to by ptr is not free
 * ensures: return NULL if failed, the new pointer if successful
 */
void *realloc(void *ptr, size_t size) {
  dbg_requires(mm_checkheap(__LINE__));
  block_t *block = payload_to_header(ptr);
  size_t copysize;
  void *newptr;

  // If size == 0, then free block and return NULL
  if (size == 0) {
    free(ptr);
    dbg_printf("freeing the ptr b.c. size 0\n");
    return NULL;
  }

  // If ptr is NULL, then equivalent to malloc
  if (ptr == NULL) {
    return malloc(size);
  }

  // Otherwise, proceed with reallocation
  newptr = malloc(size);

  // If malloc fails, the original block is left untouched
  if (newptr == NULL) {
    return NULL;
  }

  // Copy the old data
  copysize = get_payload_size(block); // gets size of old payload
  if (size < copysize) {
    copysize = size;
  }
  memcpy(newptr, ptr, copysize);

  // Free the old block
  dbg_printf("freeing the old block");
  free(ptr);
  dbg_ensures(mm_checkheap(__LINE__));
  return newptr;
}

/* calloc: allocates memory for an array of nmemb elements of size bytes each
 * arguments: number of elements and size of each element
 * ensures: returns a pointer to the allocated memory;
 *          the memory is set to zero before returning.
 */
void *calloc(size_t elements, size_t size) {
  dbg_requires(mm_checkheap(__LINE__));
  void *bp;
  size_t asize = elements * size;

  if (asize / elements != size) {
    // Multiplication overflowed
    return NULL;
  }

  bp = malloc(asize);
  if (bp == NULL) {
    return NULL;
  }

  // Initialize all bits to 0
  memset(bp, 0, asize);
  dbg_ensures(mm_checkheap(__LINE__));
  return bp;
}

/******** The remaining content below are helper and debug routines ********/

/*
 * extend_heap: extends memory of heap
 * arguments: size of extension
 * usage: used in malloc and mm_init
 * ensures: returns a pointer to the block
 */
static block_t *extend_heap(size_t size) {
  /* bp represents the pointer to the payload */
  void *bp;
  dbg_printf("ENTERing extend_heap \n");
  // need to know if last block on heap is allocated to write header
  block_t *last = mem_heap_hi() - (wsize - 1);
  bool prev_alloc = get_prev_alloc(last);
  bool prev_mini = get_prev_mini(last);

  // Allocate an even number of words to maintain alignment
  size = round_up(size, dsize);
  if ((bp = mem_sbrk(size)) == (void *)-1) {
    return NULL;
  }

  // Initialize free block header/footer
  block_t *block = payload_to_header(bp);

  rewrite_block(block, true, size, prev_mini, prev_alloc, false);

  // Create new epilogue header
  block_t *next_block = find_next(block);
  write_header(next_block, 0, false, false, true);

  // Coalesce in case the previous block was free
  block = coalesce_block(block);

  dbg_ensures(mm_checkheap(__LINE__));
  dbg_printf("EXITing extend_heap \n");
  return block;
}

/*
 * coalesce_block: handle four cases in coalescing when freeing blocks or
 *                 extending heap
 * usage: free and extend_heap
 * arguments: take in the pointer to the block we are freeing
 * requires: the input argument is not allocated, since only coalesce when
 *           freeing
 * ensures: Returns a pointer to the free block after coalesing
 */
static block_t *coalesce_block(block_t *block) {
  dbg_requires(!get_alloc(block));
  dbg_printf("ENTERing coalesce \n");
  size_t size = get_size(block);
  dbg_printf("block address: %p ", block);
  block_t *block_next = find_next(block);
  dbg_printf("block_next: %p ", block_next);

  size_t next_size = get_size(block_next);

  bool prev_alloc = get_prev_alloc(block);
  bool next_alloc = get_alloc(block_next);

  if (prev_alloc && next_alloc) // Case 1
  {
    dbg_printf(" case_1 ");
    // add the block to explist
    insert_block(block, get_class(size));

  } else if (prev_alloc && !next_alloc) // Case 2
  {
    dbg_printf(" case_2 ");
    // want to remove next block and insert new block
    size += next_size;

    // also need to update the prev_mini, prev_alloc bits of next_next block
    block_t *next_next = find_next(block_next);
    rewrite_prev(next_next, false, false);
    remove_block(block_next, get_class(next_size));

    rewrite_curr(block, size, false);
    insert_block(block, get_class(size));

  } else if (!prev_alloc && next_alloc) // Case 3
  {
    dbg_printf(" case_3 ");
    // block after coalesing cannot be mini block
    rewrite_prev(block_next, false, false);

    block_t *block_prev = find_prev(block);
    dbg_printf("block_prev: %p ", block_prev);

    size_t prev_size = get_size(block_prev);
    // want to expand size of prev_block and adjust if size class different
    size += prev_size;

    /* because insert/remove rely on header, remove before rewrite/insert */
    if (get_class(prev_size) != get_class(size)) {
      // need to put new block into a different free list
      remove_block(block_prev, get_class(prev_size));
    }

    rewrite_curr(block_prev, size, false);

    if (get_class(prev_size) != get_class(size)) {
      // need to put new block into a different free list
      insert_block(block_prev, get_class(size));
    }

    // let the new block be the updated block_prev
    block = block_prev;

  } else // Case 4
  {
    dbg_printf("case_4");
    block_t *next_next = find_next(block_next);
    rewrite_prev(next_next, false, false);

    // removing block_next
    remove_block(block_next, get_class(next_size));

    block_t *block_prev = find_prev(block);
    dbg_printf("block_prev: %p ", block_prev);
    size_t prev_size = get_size(block_prev);

    // want to write new size at block_prev and remove block_next
    size += next_size + prev_size;

    // if size_class is the same, don't want to remove, insert on the same list
    if (get_class(prev_size) != get_class(size)) {
      // need to put the new block into a different free list
      remove_block(block_prev, get_class(prev_size));
    }
    rewrite_curr(block_prev, size, false);

    if (get_class(prev_size) != get_class(size)) {
      // need to put the new block into a different free list
      insert_block(block_prev, get_class(size));
    }
    block = block_prev;
  }

  dbg_ensures(!get_alloc(block));
  dbg_ensures(mm_checkheap(__LINE__));
  dbg_printf("EXITing coalesce ");
  print_heap();
  print_list();
  dbg_printf("\n");
  return block;
}

/*
 * split_block: splits block into an allocated block and a smaller free block
 *              if possible
 *
 * Arguments: pointer to the block need to be split and the size of allocation
 * Requires: only splitting block when malloc
 */
static void split_block(block_t *block, size_t asize) {
  dbg_requires(get_alloc(block));
  dbg_printf("ENTERing split_block ");
  print_heap();
  print_list();
  size_t block_size = get_size(block);

  if ((block_size - asize) >= min_block_size) {
    block_t *block_next;

    // update header and footer
    rewrite_curr(block, asize, true);

    // this is the other half after splitting
    block_next = find_next(block);
    rewrite_block(block_next, true, block_size - asize, false, true, false);

    // need to update the prev_mini bit of next block

    /* find_next works here because have at least epilogue after block_next */
    block_t *next_next = find_next(block_next);

    rewrite_prev(next_next, (block_size - asize) == min_block_size, false);

    // change the linking to be related to the free block after splitting
    insert_block(block_next, get_class(block_size - asize));
    print_heap();
    print_list();
  }

  dbg_ensures(get_alloc(block));
  dbg_ensures(mm_checkheap(__LINE__));
  dbg_printf("EXITing split_block \n");
}

/* Find a free block in the free list with the right size range
 */
static block_t *find_fit_explist(size_t asize, block_t *explist) {
  block_t *block;
  for (block = explist; block != NULL && get_size(block) > 0;
       block = get_next(block)) {

    if ((asize <= get_size(block))) {
      return block;
    }
  }
  return NULL; // no fit found
}

/* Find a free block in the mini block free list
 */
static block_t *find_fit_minilist() {
  if (seglist[0]) { // if mini block list is none empty, return the first one
    return seglist[0];
  } else {
    return NULL; // no fit found
  }
}

/*
 * Find a free block that fits by going through the linked list explist
 * Arguments: size of the required allocation
 * Ensures: returns a pointer to the free block or NULL if no fit found
 */
static block_t *find_fit(size_t asize) {
  block_t *block;
  for (size_t i = 0; i < class_sizes - 1; i++) {
    if (asize <= block_sizes[i]) {
      if (i == 0) {
        block = find_fit_minilist();
      } else {
        block = find_fit_explist(asize, seglist[i]);
      }
      if (block) {
        return block;
      }
    }
  }
  return find_fit_explist(asize, seglist[class_sizes - 1]);
}

/*
 * Checks the validity of heap and seglist
 * Arguments: line number that it's checking
 * Ensures: returns a bool indicating if heap valid
 */
bool mm_checkheap(int line) {
  block_t *block;
  block_t *prev_block;
  size_t num_free_heap = 0, num_free_list = 0;
  word_t *tmp;

  void *last = mem_heap_hi();

  // checking the prologue

  word_t *prologue = find_prev_footer(heap_start);
  if ((void *)(prologue) != mem_heap_lo()) {
    printf("prologue not at the start of the heap!\n");
    return false;
  }

  if (extract_size(*prologue) || !extract_alloc(*prologue)) {
    printf("prologue size should be 0 and allocation should be 1!\n");
    printf("size: %zu", extract_size(*prologue));
    printf("alloc: %d", extract_alloc(*prologue));
    return false;
  }

  // checking the heap starting with the first block
  block = heap_start;
  prev_block = NULL;

  while (true) {
    if (get_size(block) <= 0) {
      break;
    }

    if (block < (block_t *)mem_heap_lo()) {
      printf("block address lower than first byte in heap ");
      return false;
    }

    if (block > (block_t *)mem_heap_hi()) {
      printf("block address higher than last byte in heap ");
      return false;
    }

    if (get_alloc(block)) { // checking for allocated blocks
      if (((unsigned long)header_to_payload(block)) % ALIGN != 0) {
        printf("address not aligned!");
        return false;
      }
    } else if (!isMini(block)) { // checking for none-mini free blocks
      num_free_heap += 1;
      tmp = header_to_footer(block);
      if (((word_t *)((char *)block + get_payload_size(block) + wsize)) !=
          tmp) {
        printf("header and footer offset wrong \n");
        return false;
      }

      if (*tmp != block->header) {
        printf("content of block %p not matched: header is %zu, \
                but footer is %zu \n",
               block, block->header, *tmp);
        return false;
      }
    } else { // checking for mini block
      num_free_heap += 1;
      printf("check for mini");
    }

    if (prev_block) {
      if (get_alloc(prev_block) == 0 && get_alloc(block) == 0) {
        printf("two consecutive free blocks! \n");
        return false;
      }

      if (get_alloc(prev_block) ^ get_prev_alloc(block)) {
        printf("prev_alloc bit in header of (%p) doesn't match allocation \
                status of (%p) \n",
               block, prev_block);
      }

      if (isMini(prev_block) ^ get_prev_mini(block)) {
        printf("prev_mini bit in header of (%p) doesn't match if (%p) is mini \
                \n",
               block, prev_block);
      }
    }
    prev_block = block;
    block = find_next(block);
  }

  // block should point to the epilogue now
  // checking if the size and allocation status of the epilogue are correct

  if ((void *)block + OFFSET != last) {
    printf("epilogue not at the bottom of the stack");
    printf("heap_hi : %p", last);
    printf("epilogue: %p", (void *)block + OFFSET);
    return false;
  }

  if (get_size(block) || !get_alloc(block)) {
    printf("epilogue %p doesn't have size 0 or not marked as allocated!\n",
           block);
    printf("size: %zu", get_size(block));
    printf("alloc: %d", get_alloc(block));
    return false;
  }

  // checking the seglist by going through each explicit list
  for (size_t i = 0; i < class_sizes; i++) {
    size_t min_size, max_size;
    if (i == class_sizes - 1) {
      min_size = block_sizes[class_sizes - 2] + 1;
      max_size = 0;
    } else {
      if (i == 0) {
        min_size = 0;
      } else {
        min_size = block_sizes[i - 1] + 1;
      }
      max_size = block_sizes[i];
    }

    block = seglist[i];

    while (block != NULL) {
      num_free_list += 1;

      if (max_size && (get_size(block) > max_size)) {
        printf("size exceed largest size in size class");
        return false;
      }
      if (min_size > get_size(block)) {
        printf("size less than smallest size in size class");
        return false;
      }
      if (isMini(block)) { // Checking for mini block
        size_t prev_mini_ptr = get_prev_mini_ptr((mini_block_t *)block);
        if (prev_mini_ptr != DUMMYPTR) {
          mini_block_t *mini_prev = (mini_block_t *)prev_mini_ptr;
          if ((void *)(mini_prev->next) != (void *)block) {
            printf("\nnext of mini_prev not match curr mini :\n");
            printf("block: %p ; mini_rev: %p; ", block, mini_prev);
            printf("next of mini_prev: %p ", mini_prev->next);
            return false;
          }
        }

        mini_block_t *mini_next = ((mini_block_t *)block)->next;
        if (mini_next) {
          mini_block_t *next_mini_prev =
              (mini_block_t *)get_prev_mini_ptr(mini_next);
          if ((void *)next_mini_prev != (void *)block) {
            printf("\nprevious of mini_next not match curr block :\n");
            printf("block: %p ; mini_next: %p; ", block, mini_next);
            printf("prev of mini_next: %p ", next_mini_prev);
            return false;
          }
        }
      } else {
        if (get_next(block) == block) {
          printf("SELFLOOP!! block: %p ; get_next(block): %p  ", block,
                 get_next(block));
          return false;
        }

        if (get_next(block)) {
          if (get_prev(get_next(block)) != block) {
            printf("\nprevious of next block not match curr block :\n");
            printf("block: %p ; next: %p; ", block, get_next(block));
            printf("prev of next: %p ", get_prev(get_next(block)));
            return false;
          }

          if (block != seglist[i] &&
              (get_prev(block) == NULL || get_next(get_prev(block)) != block)) {
            printf("\nnext of previous block not match curr block :\n");
            printf("block: %p ; prev: %p; ", block, get_prev(block));
            printf("next of prev: %p ", get_next(get_prev(block)));
            return false;
          }
        }
      }
      if (get_alloc(block)) {
        printf("free block should not be marked as allocated! \n");
        return false;
      }

      block = get_next(block);
    }
  }
  if (num_free_heap != num_free_list) {
    printf("num_free_heap != num_free_list");
    printf("num in heap: %zu num in list: %zu ", num_free_heap, num_free_list);
    return false;
  }

  return true;
}

/*
 *****************************************************************************
 * The functions below are short wrapper functions to perform                *
 * bit manipulation, pointer arithmetic, and other helper operations.        *
 *                                                                           *
 * We've given you the function header comments for the functions below      *
 * to help you understand how this baseline code works.                      *
 *                                                                           *
 * Note that these function header comments are short since the functions    *
 * they are describing are short as well; you will need to provide           *
 * adequate details within your header comments for the functions above!     *
 *                                                                           *
 *                                                                           *
 * Do not delete the following super-secret(tm) lines!                       *
 *                                                                           *
 * 53 6f 20 79 6f 75 27 72 65 20 74 72 79 69 6e 67 20 74 6f 20               *
 *                                                                           *
 * 66 69 67 75 72 65 20 6f 75 74 20 77 68 61 74 20 74 68 65 20               *
 * 68 65 78 61 64 65 63 69 6d 61 6c 20 64 69 67 69 74 73 20 64               *
 * 6f 2e 2e 2e 20 68 61 68 61 68 61 21 20 41 53 43 49 49 20 69               *
 *                                                                           *
 * 73 6e 27 74 20 74 68 65 20 72 69 67 68 74 20 65 6e 63 6f 64               *
 * 69 6e 67 21 20 4e 69 63 65 20 74 72 79 2c 20 74 68 6f 75 67               *
 * 68 21 20 2d 44 72 2e 20 45 76 69 6c 0a de ba c1 e1 52 13 0a               *
 *                                                                           *
 *****************************************************************************
 */

// debuggin helpers : prints the heap and the seglist
static void print_heap() {
  dbg_printf("\nheap :");
  for (block_t *block = heap_start; get_size(block) > 0;
       block = find_next(block)) {
    if (!isMini(block)) {
      if (get_alloc(block)) {
        dbg_printf("%p size: 0x%lx, prev_mini: %d, prev_alloc: %d, alloc: %d\n",
                   block, get_size(block), get_prev_mini(block),
                   get_prev_alloc(block), get_alloc(block));
      } else {
        dbg_printf("%p size: 0x%lx, prev_mini: %d, prev_alloc: %d, alloc: %d, \
                   prev: %p, next: %p\n",
                   block, get_size(block), get_prev_mini(block),
                   get_prev_alloc(block), get_alloc(block), get_prev(block),
                   get_next(block));
      }
    } else {
      dbg_printf("%p prev: 0x%lx, prev_mini: %d, prev_alloc: %d, alloc: %d, \
                  next: %p\n",
                 block, get_prev_mini_ptr((mini_block_t *)block),
                 get_prev_mini(block), get_prev_alloc(block), get_alloc(block),
                 ((mini_block_t *)block)->next);
    }
  }
}

static void print_list() {

  dbg_printf("\nseglist: ");
  for (size_t i = 0; i < class_sizes; i++) {
    dbg_printf("\nfree list %zu: \n", i);
    if (seglist[i]) {
      if (i == 0) {
        mini_block_t *curr = (mini_block_t *)seglist[i];
        dbg_printf("%p (%p) (%d)", curr,
                   (mini_block_t *)get_prev_mini_ptr(curr),
                   get_alloc(seglist[i]));
        for (curr = curr->next;
             (curr != NULL) && (curr != (mini_block_t *)seglist[i]);
             curr = curr->next) {
          dbg_printf(" -> %p (%p) (%d)", curr,
                     (mini_block_t *)get_prev_mini_ptr(curr),
                     get_alloc((block_t *)curr));
        }
      } else {
        block_t *curr;
        dbg_printf("%p (%lx) (%d)", seglist[i], get_size(seglist[i]),
                   get_alloc(seglist[i]));
        for (curr = seglist[i]->content.dir.next;
             (curr != NULL) && (curr != seglist[i]);
             curr = curr->content.dir.next) {
          dbg_printf(" -> %p (%lx) (%d)", curr, get_size(curr),
                     get_alloc(curr));
        }
      }
    }
    dbg_printf("\n");
  }
}

// seglist helpers

/* get_class: given a size, return the index for the right size class
 *            size_class i has size range (block_size[i-1], block_sizes[i]]
 *            lower bound is 0 if i = 0
 */
static size_t get_class(size_t size) {
  for (size_t i = 0; i < class_sizes - 1; i++) {
    if (size <= block_sizes[i])
      return i;
  }
  return class_sizes - 1;
}

/* get_next: returns the next block in the free list for normal free blocks
 * Requires: block is not null and is free */

static block_t *get_next(block_t *block) {
  assert(block != NULL); // && get_alloc(block) == 0);
  return block->content.dir.next;
}

/* get_prev: returns the prev block in the free list for normal free blocks
 * Requires: block is not null and is free */
static block_t *get_prev(block_t *block) {
  assert(block != NULL); // && get_alloc(block) == 0);
  return block->content.dir.prev;
}

/* insert_block: insert block to the explist
 * usage: in split_block and coalesce
 * requires: block must not be in the explist
 * ensures: block must be in the explist */
static void insert_block(block_t *block, size_t class_index) {
  dbg_printf("ENTERing insert_block");
  assert(block != NULL && get_alloc(block) == 0);
  assert(class_index < class_sizes && class_index >= 0);

  if (class_index == 0) { // the block is a mini block
    mini_block_t *mini = (mini_block_t *)block;
    mini_block_t *head = (mini_block_t *)seglist[0];
    if (head != NULL) {
      update_prev_in_list(head, (void *)mini);
    }
    update_prev_in_list(mini, (void *)DUMMYPTR);
    mini->next = head;
    seglist[0] = (block_t *)mini;
  } else { // block is a normal free block
    if (seglist[class_index] == NULL) {
      dbg_printf("explist NULL");
      seglist[class_index] = block;
      block->content.dir.prev = NULL;
      block->content.dir.next = NULL;
    } else {
      dbg_printf("explist: %p ", seglist[class_index]);
      block->content.dir.prev = NULL;
      block->content.dir.next = seglist[class_index];
      seglist[class_index]->content.dir.prev = block;
      seglist[class_index] = block;
    }
  }
  dbg_printf("EXITing insert_block\n");
}

/* remove_mini_block: handles the special case where a mini block is being
 *                    removed from the mini block free list
 * usage: in split_block, coalesce
 *                    note we rewrite header of next block in heap elsewhere???
 */
static void remove_mini_block(block_t *block) {
  mini_block_t *mini_list = (mini_block_t *)seglist[0];
  mini_block_t *curr = (mini_block_t *)block;
  dbg_requires(curr != NULL && mini_list != NULL);

  size_t prev_mini_ptr = get_prev_mini_ptr(curr);
  mini_block_t *nextFree;

  nextFree = curr->next;

  if (prev_mini_ptr == DUMMYPTR) // current block is first block in the list
  {
    seglist[0] = (block_t *)nextFree;
  } else {
    mini_block_t *prevFree = (mini_block_t *)prev_mini_ptr;
    prevFree->next = nextFree;
  }

  if (nextFree) // current block is not the last in the list
  {
    update_prev_in_list(nextFree, (void *)prev_mini_ptr);
  }
}
/* remove_block: remove block from explist
 *
 *               note we rewrite header of next block in heap elsewhere???
 * usage: in split_block, coalesce
 * requires: block must be in the explist
 * ensures: block not in the explist */
static void remove_block(block_t *block, size_t class_index) {
  dbg_printf("class_index removing from %zu", class_index);
  assert(class_index < class_sizes && class_index >= 0);
  assert(block != NULL &&
         seglist[class_index] != NULL); // && get_alloc(block) == 0);

  if (class_index == 0) {
    // removing from mini block explist handled as a special case
    remove_mini_block(block);
  } else {
    // modifying the explist the block is in
    block_t *prevFree;
    block_t *nextFree;
    prevFree = get_prev(block);
    nextFree = get_next(block);

    if (prevFree == NULL) // current block is first block in the list
    {
      seglist[class_index] = nextFree;
    } else {
      prevFree->content.dir.next = nextFree;
    }

    if (nextFree != NULL) // current block is not the last in the list
    {
      nextFree->content.dir.prev = prevFree;
    }

    block->content.dir.next = NULL;
    block->content.dir.prev = NULL;

    // need to modify the header of next block in the heap?
  }
  // modifying the header of
  dbg_printf("exiting remove_block\n");
}

/*
 * max: returns x if x > y, and y otherwise.
 */
static size_t max(size_t x, size_t y) { return (x > y) ? x : y; }

/*
 * round_up: Rounds size up to next multiple of n
 */
static size_t round_up(size_t size, size_t n) {
  return n * ((size + (n - 1)) / n);
}

/*
 * pack: returns a header reflecting a specified size and its alloc status.
 *       If the block is allocated, the lowest bit is set to 1, and 0 otherwise.
 */
static word_t pack(size_t size, bool prev_mini, bool prev_alloc, bool alloc) {
  word_t header = size;
  header = prev_mini ? (header | prev_mini_mask) : header;
  header = prev_alloc ? (header | prev_alloc_mask) : header;
  header = alloc ? (header | alloc_mask) : header;
  return header;
}

/* isMini: given a block, check if it's a mini block by checking if
           the first 61 bits of its header is an address (8 byte-aligned but not
           16 byte-aligned) or the size (16 byte-aligned) */
static bool isMini(block_t *block) {
  return block->header & mini_mask & DUMMYPTR;
}
/*
 * extract_size: returns the size of a given header value based on the header
 *               specification above.
 */
static size_t extract_size(word_t word) { return (word & size_mask); }

/*
 * get_size: returns the size of a given block by clearing the lowest 4 bits
 *           (as the heap is 16-byte aligned).
 */
static size_t get_size(block_t *block) {
  if (isMini(block)) {
    return min_block_size;
  } else {
    return extract_size(block->header);
  }
}
/*
 * get_payload_size: returns the payload size of a given block, equal to
 *                   the entire block size minus the header and footer sizes.
 */
static word_t get_payload_size(block_t *block) {
  size_t asize = get_size(block);
  return asize - wsize;
}

/*
 * extract_prev_in_list: returns the address of the previous mini block in the
 *                       LIST of a given header of a mini block
 */
static size_t extract_prev_mini_ptr(word_t header) {
  return (header & pointer_mask);
}

/*
 * get_prev_mini_ptr: returns pointer to previous mini block in the mini free
 *                   LIST of a mini block.
 */
static size_t get_prev_mini_ptr(mini_block_t *block) {
  dbg_requires(isMini((block_t *)block));
  return extract_prev_mini_ptr(block->prev_in_list);
}

/*
 * extract_prev_mini: returns the bit indicating if prev in heap is mini block
 */
static bool extract_prev_mini(word_t header) {
  return (header & prev_mini_mask);
}

/*
 * get_prev_mini: returns the bit indicating if prev in heap is mini block
 */
static bool get_prev_mini(block_t *block) {
  return extract_prev_mini(block->header);
}

/*
 * extract_prev_alloc: returns the address of a given header of a mini block
 */
static bool extract_prev_alloc(word_t header) {
  return (header & prev_alloc_mask);
}

/*
 * get_prev_alloc: returns the prev_in_list pointer of a mini block.
 */
static bool get_prev_alloc(block_t *block) {
  return extract_prev_alloc(block->header);
}

/*
 * extract_alloc: returns the allocation status of a given header value based
 *                on the header specification above.
 */
static bool extract_alloc(word_t word) { return (bool)(word & alloc_mask); }

/*
 * get_alloc: returns true when the block is allocated based on the
 *            block header's lowest bit, and false otherwise.
 */
static bool get_alloc(block_t *block) { return extract_alloc(block->header); }

/*
 * write_header: given a block (both block_t and mini_block_t)
                 and its size (or prev_pointer), prev_mini, prev_alloc, alloc,
 *               writes an appropriate value to the block header.
 */
static void write_header(block_t *block, size_t size, bool prev_mini,
                         bool prev_alloc, bool alloc) {
  dbg_requires(block != NULL);
  block->header = pack(size, prev_mini, prev_alloc, alloc);
}

/*
 * write_footer: given a block (both block_t and mini_block_t)
                 and its size (or prev_pointer), prev_mini, prev_alloc, alloc,
 *               writes an appropriate value to the block footer by first
 *               computing the position of the footer.
 */
static void write_footer(block_t *block, size_t size, bool prev_mini,
                         bool prev_alloc, bool alloc) {
  dbg_requires(block != NULL);
  dbg_requires(get_size(block) == size && size > 0);
  word_t *footerp = header_to_footer(block);
  *footerp = pack(size, prev_mini, prev_alloc, alloc);
}

/* rewrite_block: rewrite the header and footer of a block given its
 *                size, prev_mini, prev_alloc, and alloc;
 *                and the header of a mini block given its prev_in_list,
 *                prev_mini, prev_alloc, and alloc;
 * usage:
 *                new: if the block is newly added to the heap or splitted
 *                     deals with special case for mini block, since we use
 *                     LIFO policy by adding to the front, new mini block should
 *                     have prev_mini_ptr as DUMMYPTR */
static void rewrite_block(block_t *block, bool new, size_t size, bool prev_mini,
                          bool prev_alloc, bool alloc) {
  dbg_requires(block != NULL);
  if (alloc || size > min_block_size) {
    // if the block should be allocated or a free block that is not mini
    write_header(block, size, prev_mini, prev_alloc, alloc);
    if (!alloc) {
      // write the footer of none-mini free block
      write_footer(block, size, prev_mini, prev_alloc, alloc);
    }
  } else { // the block should be mini
    if (new || !isMini(block)) {
      /* if the block is not a mini before, add it to the front of mini block
         explist, so the pointer to previous mini would be NULL, but for
         consistency, use a DUMMYPTR that set the fourth LSB 1 */
      write_header(block, DUMMYPTR, prev_mini, prev_alloc, alloc);
    } else {
      assert(isMini(block));
      // the block is a mini before, so it's already in the mini block explist
      write_header(block, get_prev_mini_ptr((mini_block_t *)block), prev_mini,
                   prev_alloc, alloc);
    }
  }
}

/*
 * find_next: returns the next consecutive block on the heap by adding the
 *            size of the block.
 */
static block_t *find_next(block_t *block) {
  dbg_requires(block != NULL);
  dbg_requires(get_size(block) != 0);
  return (block_t *)((char *)block + get_size(block));
}

/*
 * find_prev_footer: returns the footer of the previous block.
 */
static word_t *find_prev_footer(block_t *block) {
  // Compute previous footer position as one word before the header
  return &(block->header) - 1;
}

/*
 * find_prev: returns the previous block position by checking the previous
 *            block's footer and calculating the start of the previous block
 *            based on its size.
 *
 *            if the prev_mini in current block's header is set, know the
 *            previous block on the heap is a mini block
 */
static block_t *find_prev(block_t *block) {
  dbg_requires(block != NULL);
  dbg_requires(get_size(block) != 0);
  if (get_prev_mini(block)) {
    // printf("prev is a mini ");
    return prev_mini_heap(block);
  } else {
    word_t *footerp = find_prev_footer(block);

    size_t size = extract_size(*footerp);
    // printf("size in prev_footer: %zu", size);
    return (block_t *)((char *)block - size);
  }
}

/*
 * prev_mini_heap: returns the pointer to the previous mini block in the
 *                heap
 * requires: the block has prev_mini set to 1 in header
 */
static block_t *prev_mini_heap(block_t *block) {
  dbg_requires(block != NULL);
  dbg_requires(get_prev_mini(block));

  // Compute previous mini block position as two words before the header
  block_t *prev_mini_block = (block_t *)(&(block->header) - 2);
  assert(get_size(prev_mini_block) == min_block_size);
  return prev_mini_block;
}

/* list: updates the prev_in_list header for mini blocks when
 *                      inserting into and removing from mini block explist
 *
 *                      takes in the pointer to previous mini_block and old
 *                      header, combine and return new header
 */
static void update_prev_in_list(mini_block_t *mini, void *prev_block) {
  word_t old_header = mini->prev_in_list;
  mini->prev_in_list = ((word_t)prev_block) | (old_header & (~pointer_mask));
}

/* rewrite_curr: only updates the bits related to block itself: size, alloc
 * requires: block is not newly added to the heap or result of splitting */
static void rewrite_curr(block_t *block, size_t new_size, bool new_alloc) {
  bool prev_mini = get_prev_mini(block);
  bool prev_alloc = get_prev_alloc(block);
  rewrite_block(block, false, new_size, prev_mini, prev_alloc, new_alloc);
}

/* rewrite_prev: only updates bits related to prev in heap in header of block
 *               prev_mini, prev_alloc
 * requires: block is not newly added to the heap or result of splitting */
static void rewrite_prev(block_t *block, bool new_prev_mini,
                         bool new_prev_alloc) {
  size_t size = get_size(block);
  bool alloc = get_alloc(block);
  rewrite_block(block, false, size, new_prev_mini, new_prev_alloc, alloc);
}
/*
 * payload_to_header: given a payload pointer, returns a pointer to the
 *                    corresponding block.
 */
static block_t *payload_to_header(void *bp) {
  return (block_t *)((char *)bp - offsetof(block_t, content));
}

/*
 * header_to_payload: given a block pointer, returns a pointer to the
 *                    corresponding payload.
 */
static void *header_to_payload(block_t *block) {
  return (void *)(block->content.payload);
}

/*
 * header_to_footer: given a block pointer, returns a pointer to the
 *                   corresponding footer.
 */
static word_t *header_to_footer(block_t *block) {
  return (word_t *)(block->content.payload + get_size(block) - dsize);
}
