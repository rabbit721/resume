/*
 * struct block:
 *  - url: url from GET
 *  - contents: stores the buf of the web object read from server
 */

 #include <stddef.h>                     /* size_t */
 #include <sys/types.h>                  /* ssize_t */
 #include <stdarg.h>                     /* va_list */

 #define MAX_CACHE_SIZE (1024*1024)
 #define MAX_OBJECT_SIZE (100*1024)

 typedef struct block {
   size_t size;
   char *url; //URL as key
   char *contents;
   struct block *next;
   struct block *prev;
 } block;

 typedef struct linkedlist {
   block *start; //points to the first block in cache if cache nonempty
   block *end; //points to the last block in cache if have one
 } linkedlist;

 typedef struct cache {
   pthread_mutex_t *mutex;
   size_t totalInUse;
   linkedlist *blocklist;
 } cache;

cache *init_cache();
int find_block(cache *Cache, char *url, char* contents, size_t *size);
void evict_block (block *curr);
void add_block(cache *Cache, char *url, char *contents, int nbytes);
void update_block (cache *Cache, block* curr);
void delete_list(cache *Cache);
void free_cache(cache *Cache);
void print_cache(cache *Cache);
int block_exists(cache *Cache, char *url);
