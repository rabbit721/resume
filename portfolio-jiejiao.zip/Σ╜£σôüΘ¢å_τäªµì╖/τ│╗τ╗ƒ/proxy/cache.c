/*struct
url with web objects
*/

#include "cache.h"
#include "csapp.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <stdbool.h>
#include <inttypes.h>
#include <unistd.h>
#include <assert.h>

#include <pthread.h>
#include <signal.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>

/*
 * init_cache: Initialize the Cache and allocated space on heap for pointers
 *
 * return: returns the initilized Cache
 */

cache *init_cache(){
  cache *Cache = Malloc(sizeof(cache));
  Cache->totalInUse = 0;
  Cache->blocklist = Malloc(sizeof(linkedlist));
  Cache->blocklist->start = NULL;
  Cache->blocklist->end = NULL;
  Cache->mutex = Malloc(sizeof(pthread_mutex_t));
  pthread_mutex_init(Cache->mutex, NULL);
  return Cache;
}

/* find_block: when receiving an request from client, first find block in cache
 *
 * return 0 if not found, 1 if found and Successfully wrote to fd for client
 */
//
//using uri following GET request
int find_block(cache *Cache, char *url, char *contents, size_t *size){
  sio_printf("finding block for url: %s in cache\n", url);
  sio_printf("LOCKED!\n");
  print_cache(Cache);

  for (block *curr = Cache->blocklist->start; curr != NULL; curr = curr->next) {

    if (!strcmp(curr->url, url)) {//found a block with same uri
      memcpy(contents, curr->contents, curr->size);
      *size = curr->size;
      update_block(Cache, curr);

      sio_printf("UNLOCKED!\n");
      return 1;
    }
  }
  sio_printf("UNLOCKED!\n");
  print_cache(Cache);

  return 0;
}

int block_exists(cache *Cache, char *url){
  sio_printf("finding block for url: %s in cache\n", url);
  sio_printf("LOCKED!\n");
  print_cache(Cache);

  for (block *curr = Cache->blocklist->start; curr != NULL; curr = curr->next) {

    if (!strcmp(curr->url, url)) {//found a block with same uri
      update_block(Cache, curr);
      return 1;
    }
  }
  sio_printf("UNLOCKED!\n");
  print_cache(Cache);
  return 0;
}
//update block puts the block curr at the start of blocklist
//requires that mutex of Cache is locked, only called in Successful case of
//find_block
void update_block (cache *Cache, block* curr) {
  print_cache(Cache);
  block *prev_block;
  block *next_block;
  assert(curr != NULL);
  prev_block = curr->prev;
  next_block = curr->next;
  sio_printf("prev is %p, next is %p\n", prev_block, next_block);
  if (Cache->blocklist->start == curr){
    sio_printf("Block already at the start of the list\n");
    return;
  }
  //disconnect block from blocklist
  if (prev_block) {
    prev_block->next = next_block;

  }
  if (next_block) {
    next_block->prev = prev_block;
  }
  if (Cache->blocklist->end == curr){ //if curr is the end of list
    Cache->blocklist->end = prev_block;
  }

  curr->prev = NULL;
  curr->next = Cache->blocklist->start;
  Cache->blocklist->start->prev = curr;
  Cache->blocklist->start = curr;
  sio_printf("After update\n");
  print_cache(Cache);
}

//if size of current cache < max cache size, then add, else evict acc. to LRU
void add_block(cache *Cache, char *url, char *contents, int nbytes){
  //Initialize data fields of the block
  block *new = Malloc(sizeof(block));
  new->size = nbytes;
  new->url = Malloc(sizeof(char) * MAXLINE);
  new->contents = Malloc(sizeof(char) * nbytes);

  strcpy(new->url, url);
  memcpy(new->contents, contents, nbytes);

  pthread_mutex_lock(Cache->mutex);
  if (block_exists(Cache, url)) {
    pthread_mutex_unlock(Cache->mutex);
    return;
  }
  print_cache(Cache);
  sio_printf("LOCKED! ");
  sio_printf(" block for url %s of size %d\n", new->url, nbytes);
  //make room for it in the cache
  while ((MAX_CACHE_SIZE - Cache->totalInUse) < nbytes) {
    sio_printf("deleting list to make room \n");
    delete_list(Cache);
  }
  //insert at the front
  new->next = Cache->blocklist->start;
  new->prev = NULL;
  if (Cache->blocklist->start) { //if already have a block in list
    Cache->blocklist->start->prev = new;
    Cache->blocklist->start = new;
  } else {
    Cache->blocklist->start = new;
    Cache->blocklist->end = new;
  }
  Cache->totalInUse += new->size;
  sio_printf("UNLOCKED! ");
  print_cache(Cache);
  pthread_mutex_unlock(Cache->mutex);
}


//always delete from the tail
//requires blocklist nonempty, requires mutex of Cache already locked
void delete_list(cache *Cache){
  block *prev_block;
  block *curr;
  curr = Cache->blocklist->end;
  print_cache(Cache);
  sio_printf("Deleting block for url: %s \n", curr->url);
  assert(curr != NULL);
  prev_block = curr->prev;
  sio_printf("prev_block: %p \n", prev_block);
  if (prev_block) { //means block being deleted is not the only block in list
    prev_block->next = NULL;
    Cache->blocklist->end = prev_block;
  } else { //list becomes empty after deletion
    Cache->blocklist->start = NULL;
    Cache->blocklist->end = NULL;
  }
  Cache->totalInUse -= curr->size;
  evict_block(curr);
  sio_printf("AFTER delete\n");
  print_cache(Cache);
}

void evict_block (block *curr) {
  Free(curr->url);
  Free(curr->contents);
  Free(curr);
}

void free_cache (cache *Cache) {
  while(Cache->blocklist->start){
    delete_list(Cache);
  }
  assert (Cache->totalInUse == 0);
  Free(Cache->mutex);
  Free(Cache->blocklist);
  Free(Cache);
}

void print_cache(cache *Cache){
  sio_printf("\nCurrent Cache:\n");
  block *tmp = NULL;
  for (block *curr = Cache->blocklist->start; curr != NULL; curr = curr->next) {
    if (tmp) {
      if (!(curr->prev == tmp && tmp->next == curr))
        sio_printf("Fail! prev of %s is not %s\n", curr->url, tmp->url);
    }
    tmp = curr;
    sio_printf("block (%s)-> \n", curr->url);
  }
  if (Cache->blocklist->end)
    sio_printf("Cache end: (%s)\n", Cache->blocklist->end->url);
  else {
    sio_printf("Cache end: NULL\n");
  }
}
