/*
 *
 */

/* Some useful includes to help you get started */

#include "csapp.h"
#include "cache.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <stdbool.h>
#include <inttypes.h>
#include <unistd.h>
#include <assert.h>

#include <pthread.h>
#include <signal.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>

/*
 * Debug macros, which can be enabled by adding -DDEBUG in the Makefile
 * Use these if you find them useful, or delete them if not
 */
#ifdef DEBUG
#define dbg_assert(...) assert(__VA_ARGS__)
#define dbg_printf(...) fprintf(stderr, __VA_ARGS__)
#else
#define dbg_assert(...)
#define dbg_printf(...)
#endif


#define HOSTLEN 256
#define SERVLEN 8

typedef struct sockaddr SA;

/* Information about a connected client. */
typedef struct {
    struct sockaddr_in addr;    // Socket address
    socklen_t addrlen;          // Socket address length
    int *connfd;                 // Client connection file descriptor
    char host[HOSTLEN];         // Client host
    char serv[SERVLEN];         // Client service (port)
} client_info;

/* URI parsing results. */
typedef enum {
    PARSE_ERROR,
    PARSE_STATIC,
    PARSE_DYNAMIC
} parse_result;

/*
 * String to use for the User-Agent header.
 * Don't forget to terminate with \r\n
 */
static const char *header_user_agent = "User-Agent: Mozilla/5.0"
                                    " (X11; Linux x86_64; rv:3.10.0)"
                                    " Gecko/20191101 Firefox/63.0.1\r\n";
static const char *header_connection = "Connection: close\r\n";
static const char *header_proxy_connection = "Proxy-Connection: close\r\n";
static const char *request_line_format = "GET %s HTTP/1.0\r\n";
static const char *header_term = "\r\n";
static const char *url_format = "http://%s:%s%s";

bool read_requesthdrs(rio_t *rp, char* host, char *header_new,
                      char *request_line_server);
void serve(int connfd);
void clienterror(int fd, char *cause, char *errnum,
                 char *shortmsg, char *longmsg);
int parse_host(char *uri, char *host, char *path, char *port);
int proxy_request_to_server(int connfd, char *url, char *header_new, char *host,
                            char *port, char *contents, size_t *size);
void Close(int fd);
void sigpipe_handler(int sig);
void *thread(void *vargp);
void free_resources (char *host, char *serv, struct sockaddr *addr, int *connfd,
                     cache *Cache);

cache *Cache;
/*
 * read_requesthdrs - read HTTP request headers
 * Returns true if an error occurred, or false otherwise.
 */
bool read_requesthdrs(rio_t *rp, char* host, char *header_new,
                      char *request_line_server) {
    char *buf = calloc(MAXLINE, sizeof(char));
    char *header_rest = Calloc(MAXLINE, sizeof(char));
    char *header_host = Calloc(MAXLINE, sizeof(char));
    strcpy(header_host, host);
    size_t read_n = 0;
    do {
        //sio_printf(buf);
        if ((read_n = rio_readlineb(rp, buf, MAXLINE)) <= 0) {
            sio_printf("rio_readlineb encountered an error \n");
            return true;
        }

        if (strcmp(buf, header_term) == 0) {
            break;
        } else if (!strstr(buf, ":")){
            sio_printf(buf);
            sio_printf("Request header invalid, no : found!\n");
            return true;
        }

        //handle cases for special headers separately
        if (strncmp(buf, "Host: ", strlen("Host: ")) == 0) { //client specifies Host header
          strcpy(header_host, buf);
        } else if (!strstr(buf, "Connection: ")
                   && !strstr(buf, "Proxy-Connection: ")
                   && !strstr(buf, "User-Agent: ")) {
          //concat the other headers to rest
          strcat(header_rest, buf);
        }

    } while(strncmp(buf, "\r\n", sizeof("\r\n")));

    strcpy(header_new, request_line_server);
    strcat(header_new, header_host);
    strcat(header_new, header_user_agent);
    strcat(header_new, header_connection);
    strcat(header_new, header_proxy_connection);
    strcat(header_new, header_rest);
    strcat(header_new, header_term);
    //sio_printf("new header: \n%s", header_new);
    //sio_printf("header_len: %d\n", header_len);
    return false;
}

/* parsing uri of form "http://hostname:port/path" */
int parse_host(char *uri, char *host, char *port, char *path) {
  if (strncmp(uri, "http://", strlen("http://"))) {
    sio_printf("uri doesn't start with http://\n");
    return -1;
  }
  char *host_pos, *port_pos, *path_pos;
  host_pos = uri + strlen("http://");
  port_pos = strstr(host_pos, ":");
  path_pos = strstr(host_pos, "/");

  if (!path_pos) {
    sio_fprintf(STDERR_FILENO, "suffix not found!\n");
    return -1;
  }
  strcpy(path, path_pos);
  *path_pos = '\0'; //set it to NULL to get port

  if (port_pos) {
    //set it to be NULL terminator \0 to get the host
    strcpy(port, port_pos + 1);
    *port_pos = '\0';
  } else {
    strcpy(port,"80"); //default port to be 80
  }

  strcpy(host, host_pos);
  return 0;
}

/*
 * serve - handle one HTTP request/response transaction
 */
void serve(int connfd) {
    // Get some extra info about the client (hostname/port)
    // This is optional, but it's nice to know who's connected

    rio_t rio;
    rio_readinitb(&rio, connfd);

    /* Read request line */
    char *buf = Malloc(MAXLINE);
    if (rio_readlineb(&rio, buf, MAXLINE) <= 0) {
        return;
    }

    sio_printf("%s", buf);

    /* Parse the request line and check if it's well-formed */
    char method[MAXLINE];
    char uri[MAXLINE];
    char version;
    char fullurl[MAXLINE];


    /* sscanf must parse exactly 3 things for request line to be well-formed */
    /* version must be either HTTP/1.0 or HTTP/1.1 */
    if (sscanf(buf, "%s %s HTTP/1.%c", method, uri, &version) != 3
            || (version != '0' && version != '1')) {
        clienterror(connfd, buf, "400", "Bad Request",
                "Proxy received a malformed request");
        Free(buf);
        return;
    }
    sio_printf("uri: %s\n", uri);

    char host[MAXLINE], port[MAXLINE], path[MAXLINE], header_new[MAXLINE];
    sio_printf("parsing host\n");
    if (parse_host(uri, host, port, path) < 0){//get host, port, path
        sio_printf("parse_host failed\n");
        Free(buf);
        return;
    }

    sio_printf("host: %s, port: %s, path: %s\n", host, port, path);
    sprintf(fullurl, url_format, host, port, path);


    char request_line_server[MAXLINE];
    sprintf(request_line_server, request_line_format, path);
    /* Check that the method is GET */
    if (strncasecmp(method, "GET", sizeof("GET"))) {
        clienterror(connfd, method, "501", "Not Implemented",
                "Proxy does not implement this method");
        Free(buf);
        return;
    }

    /* Check if reading request headers caused an error */
    if (read_requesthdrs(&rio, host, header_new, request_line_server)) {
      Free(buf);
      return;
    }
    //sio_printf("2. new header: \n%s", header_new);
    //sio_printf("new header ends\n");

    //First check if response is cached
    char *contents_buf = Malloc(sizeof(char) * MAX_OBJECT_SIZE);
    size_t *size = Malloc(sizeof(int));
    size_t writen_n = 0;

    pthread_mutex_lock(Cache->mutex);

    if (find_block(Cache, fullurl, contents_buf, size)) {
      pthread_mutex_unlock(Cache->mutex);
      writen_n = rio_writen(connfd, contents_buf, *size); //write to client fd
      if (writen_n < 0) {
        sio_printf("error when writing response to client fd");
      } else {
        sio_printf("Successfully wrote %ld bytes from cache to client\n",
                   writen_n);
      }
      Free(contents_buf);
      Free(buf);
      Free(size);
      return;
    } else {
      pthread_mutex_unlock(Cache->mutex);

      /* If response not cached;
       * Proxy forward request to server and write response to client */
      if (proxy_request_to_server(connfd, fullurl, header_new, host, port,
                                  contents_buf, size) > 0) {
        add_block(Cache, fullurl, contents_buf, *size);
      }

      Free(contents_buf);
      Free(buf);
      Free(size);
    }
}

/*
 * clienterror - returns an error message to the client
 */
void clienterror(int fd, char *cause, char *errnum,
        char *shortmsg, char *longmsg) {
    char buf[MAXLINE];
    char body[MAXBUF];
    size_t buflen;
    size_t bodylen;

    /* Build the HTTP response body */
    bodylen = snprintf(body, MAXBUF,
            "<!DOCTYPE html>\r\n" \
            "<html>\r\n" \
            "<head><title>Tiny Error</title></head>\r\n" \
            "<body bgcolor=\"ffffff\">\r\n" \
            "<h1>%s: %s</h1>\r\n" \
            "<p>%s: %s</p>\r\n" \
            "<hr /><em>The Tiny Web server</em>\r\n" \
            "</body></html>\r\n", \
            errnum, shortmsg, longmsg, cause);
    if (bodylen >= MAXBUF) {
        return; // Overflow!
    }

    /* Build the HTTP response headers */
    buflen = snprintf(buf, MAXLINE,
            "HTTP/1.0 %s %s\r\n" \
            "Content-Type: text/html\r\n" \
            "Content-Length: %zu\r\n\r\n", \
            errnum, shortmsg, bodylen);
    if (buflen >= MAXLINE) {
        return; // Overflow!
    }

    /* Write the headers */
    if (rio_writen(fd, buf, buflen) < 0) {
        sio_fprintf(STDERR_FILENO, "Error writing error response headers to client\n");
        return;
    }

    /* Write the body */
    if (rio_writen(fd, body, bodylen) < 0) {
        sio_fprintf(STDERR_FILENO, "Error writing error response body to client\n");
        return;
    }
}


/* - Requires: uri not found in cache
 * - Should connect to server and record response in cache */
int proxy_request_to_server(int connfd, char *url, char *header_new, char *host,
                            char *port, char *contents_buf, size_t *size) {
  int serverfd;
  rio_t server_rio;
  size_t writen_n = 0, read_n = 0;
  char *server_buf = Malloc(MAXLINE * sizeof(char));
  //char *contents_buf = Malloc(MAX_OBJECT_SIZE * sizeof(char));
  size_t nbytes = 0;
  bool fit = 1;

  serverfd = open_clientfd(host, port);
  if (serverfd < 0) {
      sio_fprintf(STDERR_FILENO, "Failed to connect to server %s:%s\n", host, port);
      Free(server_buf);
      //Free(contents_buf);
      return 0;
  }

  writen_n = rio_writen(serverfd, header_new, strlen(header_new));
  //sio_printf("header_new: %s", header_new);
  //sio_printf("length of header_new: %lx\n", strlen(header_new));
  if (writen_n < 0) {
    sio_printf("rio_written encountered error: %d\n", errno);
    Close(serverfd);
    Free(server_buf);
    //Free(contents_buf);
    return 0;
  } else {
    sio_printf("rio_writen wrote %lx to serverfd\n", writen_n);
  }

  rio_readinitb(&server_rio, serverfd);
  while((read_n = rio_readnb(&server_rio, (void *)server_buf, MAXLINE)) != 0) {
    if (read_n < 0) {
      sio_printf("rio_readlineb encountered error\n");
      Close(serverfd);
      Free(server_buf);
      //Free(contents_buf);
      return 0;
    }
    nbytes += read_n;
    //sio_printf("nbytes %ld\n", nbytes);

    if (nbytes >= MAX_OBJECT_SIZE) {
      sio_printf("nbytes exceed MAX_OBJECT_SIZE\n");
      fit = 0;
    }

    if (fit) { //if contents fit in a block
      memcpy((void *)(contents_buf + nbytes - read_n), (void *)server_buf, read_n);
    }

    sio_printf("read %lx bytes from server's response\n", read_n);
    writen_n = rio_writen(connfd, server_buf, read_n);
    if (writen_n < 0) {
      sio_printf("rio_written encountered error: %d\n", errno);
      Close(serverfd);
      Free(server_buf);
      //Free(contents_buf);
      return 0;
    } else {
      sio_printf("rio_writen wrote %lx to clientfd\n", writen_n);
    }

  }

  if (fit) {
    *size = nbytes;
    //add_block(Cache, url, contents_buf, nbytes);
    return 1;
  }


  sio_printf("closing clientfd\n");
  Close(serverfd);
  Free(server_buf);
  //Free(contents_buf);
  return 0;
}

/*
 * Usage: A wrapper for close, closes the file descriptor with error handling
 */
void Close(int fd) {
  if (close (fd) < 0) {
    sio_printf("closing fd failed\n");
  }
}

int main(int argc, char **argv) {
    sio_printf("%s", header_user_agent);
    int listenfd;
    pthread_t tid;
    Signal(SIGPIPE, sigpipe_handler);
    /* Check command line args */
    if (argc != 2) {
        sio_fprintf(STDERR_FILENO, "usage: %s <port>\n", argv[0]);
        exit(1);
    }
    //1. listen for Client request
    listenfd = open_listenfd(argv[1]);
    if (listenfd < 0) {
        sio_fprintf(STDERR_FILENO, "Failed to listen on port: %s\n", argv[1]);
        exit(1);
    }

    //initilize Cache here
    Cache = init_cache();
    /* Allocate space on the stack for client info */

    while (1) {
        /* accept() will block until a client connects to the port */
        client_info client_data;
        client_info *client = &client_data;

        /* Initialize the length of the address */
        client->addrlen = sizeof(client->addr);

        /* accept() will block until a client connects to the port */
        client->connfd = Malloc(sizeof(int));
        *(client->connfd) = accept(listenfd,
                (SA *) &client->addr, &client->addrlen);
        if (client->connfd < 0) {
            perror("accept");
            continue;
        }

        int res = getnameinfo(
                (SA *) &client->addr, client->addrlen,
                client->host, sizeof(client->host),
                client->serv, sizeof(client->serv),
                0);

        if (res == 0) {
            sio_printf("Accepted connection from %s:%s\n", client->host, client->serv);
        } else {
            sio_fprintf(STDERR_FILENO, "getnameinfo failed: %s\n", gai_strerror(res));
        }
        pthread_create(&tid, NULL, thread, client->connfd);
        //serve(*connfd);
        //Close(*connfd);

        /* Connection is established; serve client */

    }
    //free_resources(host, serv, addr, connfd, Cache);
    return 0;
}

void sigpipe_handler(int sig) {
  int olderrno = errno;
  errno = olderrno;
}

void *thread(void *vargp) {
  int *connfd = ((int *) vargp);
  pthread_detach(pthread_self());
  /* Connection is established; serve client */
  serve(*connfd);
  Close(*connfd);

  return NULL;
}

void free_resources (char *host, char *serv, struct sockaddr *addr, int *connfd,
                     cache *Cache){
  free_cache(Cache);
  Free(connfd);
  Free(host);
  Free(serv);
  Free(addr);
}
