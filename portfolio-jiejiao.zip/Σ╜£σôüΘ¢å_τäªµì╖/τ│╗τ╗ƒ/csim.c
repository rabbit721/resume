/* csim.c --- A Cache Simulator
 * Name: Jie Jiao
 * Andrew ID: jiejiao
 *
 * Specification:
 *   The simulator takes a memory trace as input and simulate the
 *   hit/miss/evict behavior of a cache memory on this trace.
 *   At the end of the simulation it outputs the total number of
 *   hits, misses, evictions, as well as the number of dirty bytes
 *   that have been evicted and the number of dirty bytes in the
 *   cache at the end of the simulation.
 *
 * Implementation details:
 *   struct blck (block): keep track of dirtybit, valid bit, tag of each block
 *   struct st (set): keep track of an array of pointers to blocks
 *                    and their history of usage for the LRU policy
 *   The cache is implemented using an array of cache sets (sets)
 *
 * LRU policy:
 *   The LRU policy is implemented by having an array LRU of longs
 *   in each set such that LRU[i] records the index of the last memory
 *   access in the trace file that used the block/line lines[i].
 *
 *   Then when there is a load/store miss, we find the least recently
 *   used block/line by having the function find_LRU return the index
 *   of the block pointer in array lines that has the minimum of LRU.
 */

#include "contracts.h"
#include "cachelab.h"
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <stdio.h>
#include <math.h>

/* Define the struct block to keep track of valid bit, tag, dirtybit */
typedef struct blck {
  int dirtybit;
  int valid;
  long tag;
} block;

/* Define the struct set:
 *   Lines: an array of blocks since each line only contains one block
 *   The array LRU is implemented in the way that LRU[i] keeps tracks of
 *     the number of the lastest iteration that block/line lines[i] is used.
 */
typedef struct st {
  block **lines;
  long *LRU;
} set;

/* find_LRU finds the index with the min iteration count, which is an
 * indicator for the least-recently used block/line */
long find_LRU(long E, set *Set, long ct) {
  long min_index = -1;
  long min_ct = ct;
  for (long i = 0; i < E; i++) {
    if (Set->LRU[i] < min_ct) {
      min_index = i;
      min_ct = Set->LRU[i];
    }
  }
  assert(min_index >= 0 && min_index < E);
  // printf("min_ct: %lx\n", min_ct);
  return min_index;
}

/* free everything allocated */
void free_set(set **Set, long S, long E) {
  long i, j;
  if (Set == NULL) {
    return;
  }

  for (i = 0; i < S; i++) {
    if (Set[i] == NULL) {
      return;
    }

    if (Set[i]->lines == NULL) {
      free(Set[i]);
      return;
    }

    for (j = 0; j < E; j++) {
      free(Set[i]->lines[j]);
    }

    free(Set[i]->lines);
    free(Set[i]->LRU);
    free(Set[i]);
  }
}

/* initialize the array of sets, each with an array of blocks/lines
 * an array of LRU   */
set **initialize_set(long S, long E) {
  long i;
  long j;
  set **sets = (set **)calloc(sizeof(set *), S);

  if (sets == NULL) {
    printf("calloc for sets failed");
    return 0;
  }
  // initialize each set

  for (i = 0; i < S; i++) {
    sets[i] = (set *)malloc(sizeof(set));

    if (sets[i] == NULL) {
      printf("calloc for sets[%lx] failed", i);
      free_set(sets, S, E);
      return 0;
    }

    sets[i]->lines = (block **)calloc(sizeof(block *), E);

    if (sets[i]->lines == NULL) {
      printf("calloc for sets[%lx]->lines failed", i);
      free_set(sets, S, E);
      return 0;
    }

    for (j = 0; j < E; j++) {
      sets[i]->lines[j] = (block *)malloc(sizeof(block));
      if (sets[i]->lines[j] == NULL) {
        free_set(sets, S, E);
        printf("calloc for sets[%lx]->lines[%lx] failed", i, j);
        return 0;
      }
    }

    sets[i]->LRU = (long *)calloc(sizeof(long), E);

    if (sets[i]->LRU == NULL) {
      free_set(sets, S, E);
      printf("calloc for set[%lx]->LRU failed", i);
      return 0;
    }

    for (j = 0; j < E; j++) {
      sets[i]->LRU[j] = 0x0L;
      sets[i]->lines[j]->valid = 0;
      sets[i]->lines[j]->dirtybit = 0;
      sets[i]->lines[j]->tag = 0x0L;
    }
  }
  return sets;
}

// main function
int main(int argc, char *argv[]) {
  long j;

  int opt;
  long verbose, E, s, b, B;
  long S;
  const char *t;
  FILE *fp;

  size_t nread;
  long address;
  char op;
  int size;
  long ct;

  set **sets;
  /* patSi, si, patTag, tag are long created to pattern match the set bits
   * and tag bits */
  long patSi, si, patTag, tag;

  int match;
  long hits, misses, evictions, dirty_bytes_in_cache, dirty_bytes_evicted;
  block *tmp;
  long lru_index;

  hits = 0L;
  misses = 0L;
  evictions = 0L;
  dirty_bytes_in_cache = 0L;
  dirty_bytes_evicted = 0L;
  verbose = 0L;

  // parsing the arguments
  while ((opt = getopt(argc, argv, "vs:E:b:t:")) != -1) {
    switch (opt) {
    case 'v':
      verbose = 1;
      break;

    case 's':
      s = atoi(optarg);
      break;

    case 'E':
      E = atoi(optarg);
      break;

    case 'b':
      b = atoi(optarg);
      break;

    case 't':
      t = optarg;
      break;

    default: /* '?' */
      fprintf(stderr, "Usage: [-hv] -s <s> -E <E> -b <b> -t <tracefile>");
      exit(1);
    }
  }

  S = 0x1L << s;
  B = 0x1L << b;
  sets = initialize_set(S, E);

  // reading from trace file
  if ((fp = fopen(t, "r")) == NULL) {
    fclose(fp);
    exit(1);
  }

  patSi = ((0x1L << (s + b)) - 0x1L) & ~((0x1L << b) - 0x1L);
  patTag = ~((0x1L << (s + b)) - 0x1L);

  ct = 0L;
  while ((nread = fscanf(fp, " %c %lx,%i", &op, &address, &size)) != -1) {
    ct += 1L;

    si = (patSi & address) >> b;
    tag = (patTag & address) >> (s + b);
    // printf("si: %lx, tag: %lx \n", si, tag);
    assert(si >= 0 && si < S);
    match = 0;

    for (j = 0; j < E; j++) {
      tmp = sets[si]->lines[j];
      if (tmp->valid == 1 && tmp->tag == tag) {
        assert(match == 0);
        // tag exists and valid, hit for both L and S
        hits += 0x1L;
        match = 1;
        // keep track of the iteration where the line tmp is used.
        sets[si]->LRU[j] = ct;

        if (op == 'S') {
          if (!tmp->dirtybit)
            dirty_bytes_in_cache += 0x1L;
          tmp->dirtybit = 1;
        }
        break;
      }
    }
    if (!match) {
      // if no valid line with same tag matches, find lru and evict
      misses += 0x1L;

      // find the LRU and evict its content
      lru_index = find_LRU(E, sets[si], ct);

      sets[si]->LRU[lru_index] = ct;

      if (sets[si]->lines[lru_index]->valid) {
        evictions += 0x1L;
      }
      if (sets[si]->lines[lru_index]->dirtybit) {
        dirty_bytes_evicted += 0x1L;
        dirty_bytes_in_cache -= 0x1L;
        sets[si]->lines[lru_index]->dirtybit = 0;
      }

      sets[si]->lines[lru_index]->tag = tag;
      sets[si]->lines[lru_index]->valid = 1;

      if (op == 'S') {
        sets[si]->lines[lru_index]->dirtybit = 1;
        dirty_bytes_in_cache += 0x1L;
      }
    }
    if (verbose == 1) {
      printf("verbose is set");
    }
  }
  fclose(fp);

  free_set(sets, S, E);
  free(sets);
  printSummary(hits, misses, evictions, dirty_bytes_in_cache * B,
               dirty_bytes_evicted * B);

  return 0;
}
