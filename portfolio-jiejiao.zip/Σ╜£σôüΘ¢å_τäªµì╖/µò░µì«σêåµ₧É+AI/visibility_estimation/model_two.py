from matplotlib.colors import LinearSegmentedColormap as LSC
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.patheffects as PathEffects

import numpy as np
import cv2, csv
import json, os
from model_util import prep2, colormap, fft
from model_arch import build_model_two
import tensorflow as tf

cm = colormap()

filep = '../../prep/'
#csvp = '../../util/data2.csv'
csvp = './parsed.csv'
hist_file = './histories.csv'

contents = prep2(csvp)
fnames = contents[:, 0]
rt = np.array([np.array_split(elem[5:], 448) for elem in contents]).astype(float)
#rt = np.expand_dims(rt0, axis = -1)
print('before reshape', rt.shape)

rt = np.array([cv2.resize(img, (300, 300)) for img in rt])
rt = np.expand_dims(rt, axis = -1) * 255
print('after reshape', rt.shape)
As = contents[:, 2: 5].astype(float) 
Y = contents[:, 1].astype(float) / 1000

orig = np.array([cv2.imread(filep+f) for f in fnames]) 
cm = np.array([cm(cv2.imread(filep+f, cv2.IMREAD_GRAYSCALE))[:, :, :-1] for f in fnames])
fft = np.array([fft(img) for img in orig]) 

print('cm.shape, fft.shape, orig.shape', cm.shape, fft.shape, orig.shape)

#model = tf.keras.models.load_model('./model2_train_one.h5')

model = build_model_two('../visnet_one/visnet_train_seven.h5')

class myCallback(tf.keras.callbacks.Callback):
	def on_epoch_end(self, epoch, logs = {}):
		if logs.get('loss') < 0.4:
			print('loss reached below 0.4')
			self.model.stop_training = True

history = model.fit(x = {'fft': fft, 'cm': cm, 'orig' : orig, 'rawt' : rt, 'atm_light' : As}, y = Y, batch_size = 64, epochs = 50, validation_split= 0.2, callbacks = [myCallback()])

model.save('./visnet_dcp_train_one.h5')

try:
	if os.path.exists(hist_file):
		contents = [row.split(',') for row in open(hist_file)]
		contents = contents + list(np.array(list(history.items())).T)
		contents = np.array(contents)
	else:
		contents = np.array(list(history.items())).T

	print('contents prepare finished')
	with open(hist_file, 'w') as wfile:
		w = csv.writer(wfile)
		w.writerows(contents)
except:
	print('damned')


