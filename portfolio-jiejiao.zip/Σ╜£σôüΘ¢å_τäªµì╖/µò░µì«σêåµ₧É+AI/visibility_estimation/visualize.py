import tensorflow as tf
import os, cv2
import numpy as np
import matplotlib
import matplotlib.pyplot as plt

from model_util import fft, colormap

cm = colormap()

train_dir = '../../prep_448/'
train_imgs = os.listdir(train_dir)

model = tf.keras.models.load_model('./model2_train_one.h5')

succ_outputs = [layer.output for layer in model.layers][3:]
print(model.summary())
visual_model = tf.keras.models.Model(inputs = model.input, outputs = succ_outputs)

img_files = [os.path.join(train_dir, f) for f in train_imgs[:10]]

orig = np.array([cv2.imread(f) for f in img_files]) / 255
cmimg = np.array([cm(cv2.imread(f, cv2.IMREAD_GRAYSCALE))[:, :, :-1] for f in img_files]) / 255
fftimg = np.array([fft(img) for img in orig]) / 255
print('fft.shape', fftimg.shape)
print('cming.shape', cmimg.shape)

succ_feature_maps = visual_model.predict([fftimg, cmimg, orig])
print(len(succ_feature_maps))

layernames = [layer.name for layer in visual_model.layers]
print(layernames)

img_path = './m2_visual_one/'
if not os.path.exists(img_path):
	os.mkdir(img_path)
# -----------------------------------------------------------------------
# Now let's display our representations
# -----------------------------------------------------------------------
ct = 0
for feature_map, layer_name in zip(succ_feature_maps, layernames):
	if len(feature_map.shape) == 4:
		#continue
		n_features = feature_map.shape[-1]  # number of features in the feature map
		size = feature_map.shape[1]  # feature map shape (1, size, size, n_features)
		print(n_features)
		# We will tile our images in this matrix
		length = int(n_features / 15)
		display_grid = np.zeros((size * length, size * 15))

		#-------------------------------------------------
		# Postprocess the feature to be visually palatable
		#-------------------------------------------------
		for i in range(length):
			for j in range(15):
				x  = feature_map[0, :, :, i * 15 + j]
				
				#x -= x.mean()
				#x /= x.std()
				#x *=  64
				#x += 128
				#x  = np.clip(x, 0, 255).astype('uint8')
				
				display_grid[i * size : (i + 1) * size, j * size : (j + 1) * size] = x 
				# Tile each filter into a horizontal grid

		#-----------------
		# Display the grid
		#-----------------
		print('drawing')
		ct += 1
		scale = 20. / 15
		plt.title(layer_name)
		plt.figure( figsize=(scale * 15, scale * length))
		plt.grid  ( False )
		plt.imshow( display_grid, aspect='auto', cmap='viridis' )
		plt.savefig(img_path + layer_name + '.png')
	elif len(feature_map.shape) == 2:
		print(layer_name,  feature_map)
		print(list(feature_map.flatten()).count(0.) * 100 / len(feature_map.flatten()))
