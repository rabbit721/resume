from matplotlib.colors import LinearSegmentedColormap as LSC
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.patheffects as PathEffects
import numpy as np
import cv2, os

def prep2(datap):
	with open(datap, 'r') as training_file:
		contents = np.array([r[:-1].split(',') for r in training_file if len(r.split(',')[5:]) / 448.0 == 448.0])
		
	print(len(contents))
	print(contents.shape)
	#print((contents[0][0].shape))
	return contents

def prep(filep, csvp, num = None):
    fns = os.listdir(filep)
    if num == 1: #pseudocoloring
        cm = colormap()
        with open(csvp, 'r') as training_file:
            '''contents = [[cm(cv2.imread('../../data/prep2/' + row.split(" ")[0][-33:]))[:, :, 2], float(row.split(" ")[1][:-1])]
                      for row in training_file if row.split(" ")[0][-33:] in fns]'''
            contents = [[cm(cv2.resize(cv2.imread(filep + row.split(",")[0][-33:], cv2.IMREAD_GRAYSCALE), (300, 300)))[:, :, :-1],
                         float(row.split(",")[1][:-1])]
                        for row in training_file if row.split(",")[0][-33:] in fns]
    elif num == 2: #fft
        with open(csvp,'r') as training_file:
            contents = [[fft(cv2.resize(cv2.imread(filep + row.split(",")[0][-33:]), (300, 300))), float(row.split(",")[1][:-1])]
                        for row in training_file if row.split(",")[0][-33:] in fns]
    else:
        with open(csvp, 'r') as training_file:
            contents = [[cv2.resize(cv2.imread(filep + row.split(",")[0][-33:]), (300, 300)),
                         float(row.split(",")[1][:-1])]
                        for row in training_file if row.split(",")[0][-33:] in fns]
    print(len(contents))
    print('image size: ' + str(contents[0][0].shape))
    return contents

def convert_to_labels2(y_num):
    labels = list(y_num)
    for i in range(len(labels)):
        if labels[i] <= 10000:
            labels[i] = 0
        elif labels[i] <= 20000:
            labels[i] = 1
        else:
            labels[i] = 2
    return labels

def convert_to_labels(y_num):
    labels = list(y_num)
    for i in range(len(labels)):
        if labels[i] <= 5000:
            labels[i] = 0
        elif labels[i] <= 5000:
            labels[i] = 1
        elif labels[i] <= 10000:
            labels[i] = 2
        elif labels[i] <= 15000:
            labels[i] = 3
        else:
            labels[i] = 4
    return labels

def fashion_scatter(x, colors):
    # choose a color palette with seaborn.
    num_classes = len(np.unique(colors))
    palette = np.array(sns.color_palette("hls", num_classes))

    # create a scatter plot.
    f = plt.figure(figsize=(8, 8))
    ax = plt.subplot(aspect='equal')
    sc = ax.scatter(x[:,0], x[:,1], lw=0, s=40, c=palette[colors.astype(np.int)])
    '''plt.xlim(-25, 25)
    plt.ylim(-25, 25)'''
    ax.axis('off')
    ax.axis('tight')

    # add the labels for each digit corresponding to the label
    txts = []

    for i in range(num_classes):

        # Position of each label at median of data points.

        xtext, ytext = np.median(x[colors == i, :], axis=0)
        txt = ax.text(xtext, ytext, str(i), fontsize=24)
        txt.set_path_effects([
            PathEffects.Stroke(linewidth=5, foreground="w"),
            PathEffects.Normal()])
        txts.append(txt)

    return f, ax, sc, txts

def fft(img):
    freq = np.fft.fft2(img)
    sft = np.fft.fftshift(freq)
    #mag_spec = 20 * np.log(np.abs(sft))

    rows, cols = img.shape[:2]
    crow, ccol = int(rows/2), int(cols/2)
    #print('sft.shape', sft.shape)
    sft[crow - 25: crow + 25, ccol - 25: ccol + 25, :] = 0
    inv = np.fft.ifftshift(sft)
    invfft = np.abs(np.fft.ifft2(inv))
    return invfft

def colormap():
    colors = [(0, 0, 0), (126/255, 0, 126/255), (3/255, 0, 253/255), (0, 125/255, 5/255), (251/255, 254/255, 0), (1, 5/255, 0)]
    # R -> G -> B
    n_bins = [3, 6, 10, 100]  # Discretizes the interpolation into bins
    cmap_name = 'my_list'
    some_matrix = np.random.rand(10,10)

    #fig, axs = plt.subplots(2, 2, figsize=(6, 9))

    cm = LSC.from_list(cmap_name, colors, N=256)
    print(type(cm))
    # Fewer bins will result in "coarser" colomap interpolation
    #im = plt.matshow(some_matrix, cmap=cm)

    #plt.colorbar(im)
    return cm
