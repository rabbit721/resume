from matplotlib.colors import LinearSegmentedColormap as LSC
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.patheffects as PathEffects
import numpy as np
import cv2
import json, os

from model_util import fashion_scatter, convert_to_labels, convert_to_labels2, fft, colormap
cm = colormap()

csvp = '../../util/data2.csv'
filep = '../../prep/'
fns = os.listdir(filep)

with open(csvp, 'r') as training_file:
	cm_contents = [[cm(cv2.imread(filep + row.split(",")[0][-33:], cv2.IMREAD_GRAYSCALE))[:, :, :-1],
					int(int(row.split(",")[1]) / 1000)]
					for row in training_file if row.split(",")[0][-33:] in fns]
					#and int(row.split(",")[0][-16:-14]) in range(10, 17)]

data = np.array(cm_contents).T
print(data.shape)

X = np.array(list(data[0]))
print(X.shape)
X = np.array([r.flatten() for r in X])
print(X.shape)

Y = list(data[1])
Y.remove(0)
Y = np.array(Y) - 1

import seaborn as sns
sns_plot = sns.countplot(Y)
sns_plot.get_figure().savefig('output.png')
'''
from sklearn.manifold import TSNE

fashion_tsne = TSNE(n_components=2).fit_transform(X)
f, ax, sc, txts = fashion_scatter(fashion_tsne, Y)

f.savefig('./cm_vis_scatter.png')
'''
