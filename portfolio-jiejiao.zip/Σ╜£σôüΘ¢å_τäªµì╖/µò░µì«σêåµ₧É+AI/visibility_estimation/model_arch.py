import tensorflow as tf

from tensorflow.keras.models import Model
from tensorflow.keras.layers import Conv2D, Dense, Flatten, MaxPooling2D, Input, Dropout, Concatenate, BatchNormalization
from tensorflow.keras.optimizers import Adam

def build_model_two(src_model):
	model = tf.keras.models.load_model(src_model)
	
	for layer in model.layers:
		layer.trainable = False
	
	visnet = model.get_layer('concatenate').output
	print(visnet.shape)
	
	input1 = Input(shape=(300, 300, 1), name = 'rawt')
	input2 = Input(shape = (3), name = 'atm_light')

	stream1 = Conv2D(64, (1,1), activation = tf.nn.leaky_relu, name = 'new_conv2d_1')(input1)
	stream1 = Conv2D(64, (3,3), activation = tf.nn.leaky_relu, name = 'new_conv2d_2')(stream1)
	stream1 = MaxPooling2D(2, 2, name = 'new_maxP_1')(stream1)
	
	stream1 = Conv2D(128, (1,1), activation = tf.nn.leaky_relu, name = 'new_conv2d_3')(stream1)
	stream1 = Conv2D(128, (3,3), activation = tf.nn.leaky_relu, name = 'new_conv2d_4')(stream1)
	stream1 = MaxPooling2D(2, 2, name = 'new_maxP_2')(stream1)

	stream1 = Conv2D(256, (1,1), activation = tf.nn.relu, name = 'new_conv2d_5')(stream1)
	stream1 = Conv2D(256, (3,3), strides = (2, 2), activation = tf.nn.relu, name = 'new_conv2d_6')(stream1)
	stream1 = Conv2D(256, (1,1), activation = tf.nn.relu, name = 'new_conv2d_7')(stream1)
	stream1 = MaxPooling2D(2, 2, name = 'new_maxP_3')(stream1)

	stream1 = Flatten(name = 'new_flatten_1')(stream1)
	stream1 = Dense(1024, 'relu', name = 'new_dense_1')(stream1)
	stream1 = Dropout(0.4, name = 'new_dropout_1')(stream1)

	stream2 = Dense(32, 'relu', name = 'new_dense_2')(input2)
	stream2 = Dense(64, 'relu', name = 'new_dense_3')(stream2)
	stream2 = Dense(32, 'relu', name = 'new_dense_4')(stream2)
	total = Concatenate(name = 'new_concat')([stream1, stream2, visnet])

	total = Dense(4096, 'relu', name = 'new_dense_total')(total)
	total = Dense(1, 'relu', name = 'total_output')(total)
	
	model_cmb = Model([input1, input2, *model.inputs], total)
	model_cmb.compile(optimizer = Adam(lr = 0.00001), loss = 'mse', metrics = ['mape'])
	model_cmb.summary()
	return model_cmb

def build_visnet():
	input1 = Input(shape=(448, 448, 3), name = 'fft')
	stream1 = Conv2D(32, (1,1), activation = tf.nn.leaky_relu)(input1)
	stream1 = Conv2D(32, (3,3), activation = tf.nn.leaky_relu)(stream1)
	stream1 = MaxPooling2D(2, 2)(stream1)

	input2 = Input(shape=(448, 448, 3), name = 'cm')
	stream2 = Conv2D(32, (1,1), activation = tf.nn.leaky_relu)(input2)
	stream2 = Conv2D(32, (3,3), activation = tf.nn.leaky_relu)(stream2)
	stream2 = MaxPooling2D(2, 2)(stream2)

	input3 = Input(shape=(448, 448, 3), name = 'orig')
	stream3 = Conv2D(32, (1,1), activation = tf.nn.leaky_relu)(input3)
	stream3 = Conv2D(32, (3,3), activation = tf.nn.leaky_relu)(stream3)
	stream3 = MaxPooling2D(2, 2)(stream3)

	stream1 = tf.keras.layers.add([stream1, stream2, stream3])

	stream1 = Conv2D(64, (1,1), activation = tf.nn.relu)(stream1)
	stream1 = Conv2D(64, (3,3), activation = tf.nn.relu)(stream1)
	stream1 = MaxPooling2D(2, 2)(stream1)

	stream2 = Conv2D(64, (1,1), activation = tf.nn.relu)(stream2)
	stream2 = Conv2D(64, (3,3), activation = tf.nn.relu)(stream2)
	stream2 = MaxPooling2D(2, 2)(stream2)

	stream3 = Conv2D(64, (1,1), activation = tf.nn.relu)(stream3)
	stream3 = Conv2D(64, (3,3), activation = tf.nn.relu)(stream3)
	stream3 = MaxPooling2D(2, 2)(stream3)

	'''
	stream1 = tf.keras.layers.add([stream1, stream2, stream3])

	stream1 = Conv2D(256, (3,3), activation = tf.nn.relu)(stream1)
	stream1 = Conv2D(128, (1,1), strides = (2, 2), activation = tf.nn.relu)(stream1)
	stream1 = Conv2D(256, (3,3), activation = tf.nn.relu)(stream1)
	stream1 = MaxPooling2D(2, 2)(stream1)

	stream2 = Conv2D(256, (3,3), activation = tf.nn.relu)(stream2)
	stream2 = Conv2D(128, (1,1), strides = (2, 2), activation = tf.nn.relu)(stream2)
	stream2 = Conv2D(256, (3,3), activation = tf.nn.relu)(stream2)
	stream2 = MaxPooling2D(2, 2)(stream2)

	stream3 = Conv2D(256, (3,3), activation = tf.nn.relu)(stream3)
	stream3 = Conv2D(128, (1,1), strides = (2, 2), activation = tf.nn.relu)(stream3)
	stream3 = Conv2D(256, (3,3), activation = tf.nn.relu)(stream3)
	stream3 = MaxPooling2D(2, 2)(stream3)

	'''
	stream23 = tf.keras.layers.add([stream2, stream3])

	stream1 = Flatten()(stream1)
	stream1 = Dense(512, activation = tf.nn.leaky_relu)(stream1)
	stream1 = BatchNormalization()(stream1)


	stream23 = Flatten()(stream23)
	stream23 = Dense(1024, activation = tf.nn.relu)(stream23)
	stream23 = BatchNormalization()(stream23)

	total = Concatenate()([stream1, stream23])
	total = Dense(2048, activation = tf.nn.relu)(total)
	'''
	total = Concatenate()([stream1, stream2, stream3])
	'''
	total = Dense(1, 'linear')(total)

	model = Model([input1, input2, input3], total)

	from tensorflow.keras.optimizers import Adam

	model.compile(optimizer= Adam(lr = 0.00001), loss = 'mse', metrics = ['mape'])
	print('model compile finished')


	                                                 
